﻿# 변환 도구(ffmpeg, 무료 공개 프로그램)를 Windows 기본 설치 도구(winget)로 설치합니다.
$Host.UI.RawUI.WindowTitle = '변환도구 설치하기'
Write-Host ''
Write-Host '  ===== 변환 도구(ffmpeg) 설치 =====' -ForegroundColor Green
Write-Host '  드론·아이폰의 H.265 영상을 바꾸는 데 필요한 무료 프로그램이에요. (약 100MB)'
Write-Host '  Windows에 들어 있는 「winget」으로 설치해요. 동의를 묻는 질문이 나오면 Y 를 누르세요.'
Write-Host ''
$have = (Get-Command ffmpeg -ErrorAction SilentlyContinue) -or (Test-Path (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\ffmpeg.exe')) -or
  [bool](Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') -Filter 'ffmpeg.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1)
if ($have) { Write-Host '  ✅ 이미 설치되어 있어요. 「드론영상_변환하기」를 쓰면 돼요.' -ForegroundColor Green; Read-Host '  Enter 키를 누르면 닫혀요'; exit 0 }
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Host '  ⚠ 이 PC에 winget이 없어요. Microsoft Store에서 「앱 설치 관리자」를 업데이트한 뒤 다시 해 주세요.' -ForegroundColor Yellow
  Read-Host '  Enter 키를 누르면 닫혀요'; exit 1
}
winget install -e --id Gyan.FFmpeg
Write-Host ''
if ($LASTEXITCODE -eq 0) { Write-Host '  ✅ 설치 끝! 이제 「드론영상_변환하기」를 쓸 수 있어요.' -ForegroundColor Green }
else { Write-Host '  ⚠ 설치가 끝나지 않았어요. 인터넷 연결을 확인하고 다시 해 주세요.' -ForegroundColor Yellow }
Read-Host '  Enter 키를 누르면 닫혀요'
