﻿# 영상·사진 편집기 도우미
# - 이 컴퓨터 안(127.0.0.1)에서만 열리는 작은 서버입니다. 외부(인터넷)에서는 접속할 수 없습니다.
# - 편집기 화면을 열어 주고, 브라우저가 못 여는 드론·아이폰 H.265(HEVC) 영상을 ffmpeg로 바꿔 줍니다.
# - 편집기 창을 닫으면 잠시 뒤 스스로 꺼집니다.
param([int]$Port = 48653, [switch]$NoBrowser, [string]$ProjDir = '', [switch]$LanTest)   # LanTest: 시험할 때만 (다른 기기 연결을 이 PC 안에서만 열어 봄)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$html = Join-Path $root '영상사진편집기.html'
$outDir = Join-Path $root '변환된_영상'
$tmp = Join-Path $env:TEMP 'vpe_work'
$logFile = Join-Path $tmp 'helper.log'
New-Item -ItemType Directory -Force $tmp, $outDir | Out-Null
function Log($s) { try { Add-Content -Path $logFile -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $s) -Encoding utf8 } catch {} }

function Open-Editor {
  if ($NoBrowser) { return }
  $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($edge) { Start-Process $edge "--app=http://127.0.0.1:$Port/" } else { Start-Process "http://127.0.0.1:$Port/" }
}

# 이미 켜져 있으면 창만 열고 끝 (예전 버전 도우미가 켜져 있으면 끄고 새로 시작)
$HelperVersion = 'vpe ok v26'   # v9: 영상 보내기를 따로 일하는 일꾼에게 (재생 멈춤 해결) · v26: 🎞 미리보기용 가벼운 사본 (4K·60프레임 재생 멈춤 해결)
try {
  $r = Invoke-WebRequest "http://127.0.0.1:$Port/ping" -UseBasicParsing -TimeoutSec 2
  if ($r.Content -eq $HelperVersion) { Open-Editor; exit 0 }
  if ("$($r.Content)" -like 'vpe*') {
    # 같은 포트를 쓰는 예전 도우미만 끔 (다른 포트의 도우미는 건드리지 않음)
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object {
      $_.ProcessId -ne $PID -and $_.CommandLine -match 'helper\.ps1' -and (($_.CommandLine -match "-Port\s+$Port\b") -or ($_.CommandLine -notmatch '-Port\s+\d+' -and $Port -eq 48653))
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep 1
  }
} catch {}

function Find-Tool($name) {
  $c = @((Join-Path $root "ffmpeg\bin\$name.exe"), (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\$name.exe"))
  foreach ($x in $c) { if (Test-Path $x) { return $x } }
  $g = Get-Command $name -ErrorAction SilentlyContinue; if ($g) { return $g.Source }
  $p = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') -Filter "$name.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($p) { return $p.FullName }; return $null
}
$ff = Find-Tool 'ffmpeg'; $fp = Find-Tool 'ffprobe'

# 이전에 남은 임시 파일 정리
Get-ChildItem $tmp -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'helper.log' } | Remove-Item -Force -ErrorAction SilentlyContinue

$doneDir = Join-Path $root '완성된_영상'
New-Item -ItemType Directory -Force $doneDir | Out-Null
$projDir = $(if ($ProjDir) { $ProjDir } else { Join-Path $root '작업저장' })   # 💾 편집 작업(클립 순서·효과·자막 등) 자동 저장 파일 (시험할 때만 다른 폴더)
$saves = @{}
# 프로그램 폴더 안의 파일만 다룸 (다른 곳의 파일은 열거나 보내지 않음)
function Safe-Path($p) {
  if (-not $p) { return $null }
  try { $full = [IO.Path]::GetFullPath([string]$p) } catch { return $null }
  if ($full.StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase) -and (Test-Path $full -PathType Leaf)) { return $full }
  return $null
}
# 🔒 이번 실행에서만 쓰는 비밀 열쇠 (암호용 난수 128비트 · 편집기 창에만 알려 줌)
$token = -join ((& { $b = New-Object byte[] 16; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); $b }) | ForEach-Object { '{0:x2}' -f $_ })
$jobs = @{}
$cacheFile = Join-Path $outDir '.변환기록.json'
$cache = @{}
if (Test-Path $cacheFile) { try { (Get-Content $cacheFile -Raw -Encoding utf8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $cache[$_.Name] = $_.Value } } catch {} }
function Save-Cache { try { ($cache | ConvertTo-Json -Depth 3) | Set-Content $cacheFile -Encoding utf8 } catch {} }

# 📍 파일 위치 기억: 편집기에 넣었던 영상·사진·음악이 어디 있었는지 (이름|크기 → 경로) 적어 두었다가, 이어서 하기 때 바로 찾음
$locFile = Join-Path $outDir '.파일위치.json'
$locs = @{}
if (Test-Path $locFile) { try { (Get-Content $locFile -Raw -Encoding utf8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $locs[$_.Name] = [string]$_.Value } } catch {} }
function Save-Locs { try { if ($locs.Count -gt 3000) { foreach ($k in @($locs.Keys)[0..999]) { $locs.Remove($k) } }; ($locs | ConvertTo-Json -Depth 2) | Set-Content $locFile -Encoding utf8 } catch {} }
$mediaExt = '\.(jpe?g|png|webp|gif|bmp|heic|mp4|mov|m4v|webm|mkv|avi|mp3|m4a|wav|aac|ogg|flac)$'
# 이름(+크기)로 원본 파일 찾기: ① 기억해 둔 위치 → ② 윈도우 검색 색인(내 사용자 폴더 안, 아주 빠름) → ③ 정해진 폴더를 조금 더 깊이
function Find-Media($nm, [int64]$want, [switch]$Quick) {
  $ok = { param($f) $f -and $f.Length -gt 0 -and ($want -le 0 -or $f.Length -eq $want) }
  $key = "$nm|$want"
  if ($locs.ContainsKey($key)) { $f = Get-Item -LiteralPath $locs[$key] -ErrorAction SilentlyContinue; if (& $ok $f) { return $f } }
  # ② 윈도우 검색 색인 (사용자 폴더 안의 사진·영상·음악 파일만)
  try {
    $cn = New-Object -ComObject ADODB.Connection
    $cn.Open("Provider=Search.CollatorDSO;Extended Properties='Application=Windows';")
    $scope = 'file:' + ($env:USERPROFILE -replace '\\', '/')
    $sql = "SELECT TOP 20 System.ItemPathDisplay FROM SYSTEMINDEX WHERE SCOPE='$scope' AND System.FileName = '" + ($nm -replace "'", "''") + "'"
    $rs = $cn.Execute($sql)
    while (-not $rs.EOF) { $f = Get-Item -LiteralPath ([string]$rs.Fields.Item(0).Value) -ErrorAction SilentlyContinue; if ((& $ok $f) -and $f.Name -match $mediaExt) { $rs.Close(); $cn.Close(); return $f }; $rs.MoveNext() }
    $rs.Close(); $cn.Close()
  } catch {}
  if ($Quick) { return $null }
  # ③ 정해진 폴더를 직접 찾아봄
  $desk = [Environment]::GetFolderPath('Desktop')
  $td = Team-Dir; $tdr = $(if ($td) { Join-Path $td '자료' } else { $null })   # 👥 팀 작업 폴더에 모아 둔 자료도
  $roots = @(@($tdr, 1), @((Join-Path $root '받은_부분'), 3), @((Join-Path $desk 'DJI Album'), 4), @($outDir, 1), @($doneDir, 1), @($desk, 3), @([Environment]::GetFolderPath('MyPictures'), 4), @([Environment]::GetFolderPath('MyVideos'), 4), @((Join-Path $env:USERPROFILE 'Downloads'), 3), @([Environment]::GetFolderPath('MyMusic'), 3), @($env:OneDrive, 4))
  foreach ($rd in $roots) {
    $r = $rd[0]; if (-not $r -or -not (Test-Path -LiteralPath $r)) { continue }
    $c = Get-ChildItem -LiteralPath $r -Filter $nm -File -Recurse -Depth $rd[1] -ErrorAction SilentlyContinue | Where-Object { & $ok $_ } | Select-Object -First 1
    if ($c) { return $c }
  }
  return $null
}

# 🔒 변조 검사: 공유용으로 받은 프로그램이면(tools\checksums.sha256 있음) 파일이 바뀌지 않았는지 확인하고, 바뀌었으면 실행하지 않음
$sumFile = Join-Path $PSScriptRoot 'checksums.sha256'
if (Test-Path $sumFile) {
  $bad = @()
  foreach ($line in Get-Content $sumFile -Encoding utf8) {
    if ($line -notmatch '^([0-9a-f]{64})\s+\*?(.+)$') { continue }
    $f = Join-Path $root $matches[2]
    if (-not (Test-Path -LiteralPath $f) -or (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower() -ne $matches[1]) { $bad += $matches[2] }
  }
  if ($bad.Count) {
    Log ("integrity fail: " + ($bad -join ', '))
    try { Add-Type -AssemblyName PresentationFramework; [Windows.MessageBox]::Show("프로그램 파일이 원래와 달라졌어요. 안전을 위해 실행하지 않을게요.`n`n바뀐 파일: " + ($bad -join ', ') + "`n`n처음 받은 공유 파일(zip)에서 다시 풀어서 쓰세요.", '영상·사진 편집기 - 보안 확인', 'OK', 'Warning') | Out-Null } catch {}
    exit 2
  }
}

# 이 컴퓨터 안(127.0.0.1)에서만 열림. 다른 프로그램이 이 번호를 쓰고 있으면 다음 번호로
$L = $null
foreach ($p in @($Port) + (($Port + 1)..($Port + 8))) {
  $try = New-Object Net.HttpListener; $try.Prefixes.Add("http://127.0.0.1:$p/")
  try { $try.Start(); $L = $try; $Port = $p; break } catch { Log "listen fail $p : $_"; try { $try.Close() } catch {} }
}
if (-not $L) { exit 1 }
Log "started port=$Port ffmpeg=$ff"
Open-Editor
$lastPing = Get-Date; $started = Get-Date

function Send($ctx, [int]$code, [string]$type, $body) {
  $res = $ctx.Response; $res.StatusCode = $code; $res.ContentType = $type
  $res.Headers.Add('Cache-Control', 'no-store'); $res.Headers.Add('X-Frame-Options', 'DENY'); $res.Headers.Add('X-Content-Type-Options', 'nosniff'); $res.Headers.Add('Referrer-Policy', 'no-referrer')
  $bytes = if ($body -is [byte[]]) { $body } else { [Text.Encoding]::UTF8.GetBytes([string]$body) }
  $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes, 0, $bytes.Length); $res.OutputStream.Close()
}
function Json($ctx, $obj) { Send $ctx 200 'application/json; charset=utf-8' ($obj | ConvertTo-Json -Compress -Depth 4) }
# 파일을 조금씩 나눠 보내기 (영상 앞뒤로 이동 가능)
function Stream-Range($ctx, $req, $p) {
  $res = $ctx.Response; $f = [IO.File]::OpenRead($p)
  try {
    $len = $f.Length; $start = [int64]0; $end = $len - 1; $partial = $false
    $rh = $req.Headers['Range']
    if ($rh -and $rh -match 'bytes=(\d+)-(\d*)') { $start = [int64]$matches[1]; if ($matches[2]) { $end = [int64]$matches[2] }; $partial = $true }
    if ($partial -and ($end - $start + 1) -gt 8MB) { $end = $start + 8MB - 1 }
    if ($end -ge $len) { $end = $len - 1 }
    if ($start -ge $len) { $res.StatusCode = 416; $res.Headers.Add('Content-Range', "bytes */$len"); $res.OutputStream.Close(); return }
    $ct = switch -regex ($p) { '\.webm$' { 'video/webm' } '\.mov$' { 'video/quicktime' } default { 'video/mp4' } }
    $res.StatusCode = $(if ($partial) { 206 } else { 200 }); $res.ContentType = $ct; $res.Headers.Add('Accept-Ranges', 'bytes')
    if ($partial) { $res.Headers.Add('Content-Range', "bytes $start-$end/$len") }
    $n = $end - $start + 1; $res.ContentLength64 = $n; $f.Seek($start, 'Begin') | Out-Null
    $buf = New-Object byte[] (1MB); while ($n -gt 0) { $r = $f.Read($buf, 0, [int][math]::Min($buf.Length, $n)); if ($r -le 0) { break }; $res.OutputStream.Write($buf, 0, $r); $n -= $r }
  } catch { } finally { $f.Close(); try { $res.OutputStream.Close() } catch {} }
}
# ⚡ 영상 보내기는 「따로 일하는 일꾼(스레드)」에게 맡김
#    예전: 한 번에 한 요청만 처리 → 브라우저가 영상을 천천히 받아 가는 동안 도우미 전체가 붙잡혀서
#          다음 클립·두 번째 플레이어·자동 저장 요청이 줄을 서고, 그동안 음악만 나오고 화면은 멈춤
$streamPool = [RunspaceFactory]::CreateRunspacePool(1, 10); $streamPool.Open()
$streamJobs = New-Object System.Collections.ArrayList
$streamScript = {
  param($ctx, $p)
  $req = $ctx.Request; $res = $ctx.Response; $f = $null
  try {
    $f = [IO.File]::Open($p, 'Open', 'Read', 'ReadWrite')
    $len = $f.Length; $start = [int64]0; $end = $len - 1; $partial = $false
    $rh = $req.Headers['Range']
    if ($rh -and $rh -match 'bytes=(\d+)-(\d*)') { $start = [int64]$matches[1]; if ($matches[2]) { $end = [int64]$matches[2] }; $partial = $true }
    if ($rh -and ($end - $start + 1) -gt 4MB) { $end = $start + 4MB - 1; $partial = $true }   # 영상 플레이어(범위 요청)에게만 4MB씩 · 파일 전체 요청은 끝까지   # 한 번에 4MB씩 (짧게 끝나야 다른 요청이 빨리 돎)
    if ($end -ge $len) { $end = $len - 1 }
    if ($start -ge $len) { $res.StatusCode = 416; $res.Headers.Add('Content-Range', "bytes */$len"); return }
    $ct = switch -regex ($p) { '\.jpe?g$' { 'image/jpeg' } '\.png$' { 'image/png' } '\.webp$' { 'image/webp' } '\.wav$' { 'audio/wav' } '\.mp3$' { 'audio/mpeg' } '\.m4a$' { 'audio/mp4' } '\.webm$' { 'video/webm' } '\.mov$' { 'video/quicktime' } default { 'video/mp4' } }
    $res.StatusCode = $(if ($partial) { 206 } else { 200 }); $res.ContentType = $ct; $res.Headers.Add('Accept-Ranges', 'bytes'); $res.Headers.Add('Cache-Control', 'no-store')
    if ($partial) { $res.Headers.Add('Content-Range', "bytes $start-$end/$len") }
    $n = $end - $start + 1; $res.ContentLength64 = $n; [void]$f.Seek($start, 'Begin')
    $buf = New-Object byte[] (512KB); while ($n -gt 0) { $r = $f.Read($buf, 0, [int][math]::Min($buf.Length, $n)); if ($r -le 0) { break }; $res.OutputStream.Write($buf, 0, $r); $n -= $r }
  } catch { } finally { if ($f) { $f.Close() }; try { $res.OutputStream.Close() } catch {} }
}
# 🎤 음성으로 편집: 이 컴퓨터 안의 음성 인식 프로그램(whisper)이 알아들음 → 목소리는 밖으로 나가지 않음
#    처음 한 번 학습 자료를 올려 두고(whisper-server) 계속 씀 → 명령마다 기다리는 시간이 짧음
$wDir = Join-Path $root 'tools\whisper'; $wExe = Join-Path $wDir 'bin\Release\whisper-server.exe'; $wModel = Join-Path $wDir 'ggml-small.bin'; $wPort = 48711
function Voice-Ready { (Test-Path $wExe) -and (Test-Path $wModel) -and ((Get-Item $wModel).Length -gt 100MB) }
# 지난번에 남은 음성 인식 프로그램은 정리 (이 편집기 폴더의 것만)
Get-CimInstance Win32_Process -Filter "Name='whisper-server.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.ExecutablePath -eq $wExe } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$voiceState = [hashtable]::Synchronized(@{ proc = $null })
$voiceScript = {
  param($ctx, $wav, $st, $exe, $model, $port, $prompt)
  $res = $ctx.Response
  function Reply($obj) { $b = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress)); $res.StatusCode = 200; $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $b.Length; $res.OutputStream.Write($b, 0, $b.Length); $res.OutputStream.Close() }
  try {
    Add-Type -AssemblyName System.Net.Http
    $base = "http://127.0.0.1:$port"; $hc = New-Object System.Net.Http.HttpClient; $hc.Timeout = [TimeSpan]::FromSeconds(90)
    $alive = { try { $r = $hc.GetAsync("$base/").Result; return $true } catch { return $false } }
    if (-not $st.proc -or $st.proc.HasExited -or -not (& $alive)) {
      $th = [Math]::Max(2, [Environment]::ProcessorCount - 2)
      $st.proc = Start-Process -FilePath $exe -WorkingDirectory (Split-Path $model) -ArgumentList @('-m', (Split-Path $model -Leaf), '-l', 'ko', '-t', $th, '--host', '127.0.0.1', '--port', $port) -WindowStyle Hidden -PassThru   # 폴더 이름의 한글을 음성 인식 프로그램이 못 읽어서, 모델 폴더 안에서 영어 이름으로 엶
      $ok = $false; for ($i = 0; $i -lt 120; $i++) { Start-Sleep -Milliseconds 500; if (& $alive) { $ok = $true; break }; if ($st.proc.HasExited) { break } }
      if (-not $ok) { Reply @{ ok = $false; error = 'start' }; return }
    }
    if (-not $wav) { Reply @{ ok = $true; warm = $true }; return }
    $mp = New-Object System.Net.Http.MultipartFormDataContent
    $bytes = [IO.File]::ReadAllBytes($wav); $fc = New-Object System.Net.Http.ByteArrayContent(, $bytes); $fc.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse('audio/wav')
    $mp.Add($fc, 'file', 'voice.wav')
    $mp.Add((New-Object System.Net.Http.StringContent('0.0')), 'temperature')
    $mp.Add((New-Object System.Net.Http.StringContent('json')), 'response_format')
    $mp.Add((New-Object System.Net.Http.StringContent('ko')), 'language')
    if ($prompt) { $mp.Add((New-Object System.Net.Http.StringContent($prompt, [Text.Encoding]::UTF8)), 'prompt') }
    $t0 = Get-Date; $r = $hc.PostAsync("$base/inference", $mp).Result; $txt = $r.Content.ReadAsStringAsync().Result
    $text = ''; try { $text = ($txt | ConvertFrom-Json).text } catch { $text = $txt }
    Reply @{ ok = $true; text = ([string]$text).Trim(); ms = [int]((Get-Date) - $t0).TotalMilliseconds }
  } catch { try { Reply @{ ok = $false; error = "$_" } } catch {} } finally { if ($wav) { Remove-Item $wav -Force -ErrorAction SilentlyContinue } }
}
# 🗣 말소리 자동 자막: 영상의 한 구간 소리를 꺼내 → 음성 인식(낱말마다 시각) → 편집기가 자막으로 나눠 넣음
$subScript = {
  param($ctx, $src, $ss, $dur, $st, $exe, $model, $port, $ffPath, $tmpDir, $prompt)
  $res = $ctx.Response
  function Reply($obj) { $b = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 6)); $res.StatusCode = 200; $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $b.Length; $res.OutputStream.Write($b, 0, $b.Length); $res.OutputStream.Close() }
  $wav = Join-Path $tmpDir ([guid]::NewGuid().ToString('N') + '.wav')
  try {
    Add-Type -AssemblyName System.Net.Http
    $p = Start-Process -FilePath $ffPath -ArgumentList @('-v', 'error', '-y', '-ss', $ss, '-t', $dur, '-i', "`"$src`"", '-vn', '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', "`"$wav`"") -WindowStyle Hidden -PassThru -Wait
    if (-not (Test-Path $wav) -or (Get-Item $wav).Length -lt 2000) { Reply @{ ok = $false; error = 'noaudio' }; return }
    $base = "http://127.0.0.1:$port"; $hc = New-Object System.Net.Http.HttpClient; $hc.Timeout = [TimeSpan]::FromSeconds(600)
    $alive = { try { $r = $hc.GetAsync("$base/").Result; return $true } catch { return $false } }
    if (-not $st.proc -or $st.proc.HasExited -or -not (& $alive)) {
      $th = [Math]::Max(2, [Environment]::ProcessorCount - 2)
      $st.proc = Start-Process -FilePath $exe -WorkingDirectory (Split-Path $model) -ArgumentList @('-m', (Split-Path $model -Leaf), '-l', 'ko', '-t', $th, '--host', '127.0.0.1', '--port', $port) -WindowStyle Hidden -PassThru
      $ok = $false; for ($i = 0; $i -lt 120; $i++) { Start-Sleep -Milliseconds 500; if (& $alive) { $ok = $true; break }; if ($st.proc.HasExited) { break } }
      if (-not $ok) { Reply @{ ok = $false; error = 'start' }; return }
    }
    $mp = New-Object System.Net.Http.MultipartFormDataContent
    $fc = New-Object System.Net.Http.ByteArrayContent(, [IO.File]::ReadAllBytes($wav)); $fc.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse('audio/wav'); $mp.Add($fc, 'file', 'clip.wav')
    $mp.Add((New-Object System.Net.Http.StringContent('verbose_json')), 'response_format'); $mp.Add((New-Object System.Net.Http.StringContent('ko')), 'language'); $mp.Add((New-Object System.Net.Http.StringContent('0.0')), 'temperature')
    if ($prompt) { $mp.Add((New-Object System.Net.Http.StringContent($prompt, [Text.Encoding]::UTF8)), 'prompt') }
    $txt = $hc.PostAsync("$base/inference", $mp).Result.Content.ReadAsStringAsync().Result
    $j = $txt | ConvertFrom-Json; $words = @()
    foreach ($sg in @($j.segments)) { if ($sg.no_speech_prob -gt 0.8) { continue }; foreach ($w in @($sg.words)) { if ($w.word -and $w.word.Trim()) { $words += ,@([string]$w.word, [double]$w.start, [double]$w.end) } } }
    Reply @{ ok = $true; text = ([string]$j.text).Trim(); words = $words }
  } catch { try { Reply @{ ok = $false; error = "$_" } } catch {} } finally { Remove-Item $wav -Force -ErrorAction SilentlyContinue }
}
function Sub-Async($ctx, $src, $ss, $dur, $prompt) {
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($subScript).AddArgument($ctx).AddArgument($src).AddArgument($ss).AddArgument($dur).AddArgument($voiceState).AddArgument($wExe).AddArgument($wModel).AddArgument($wPort).AddArgument($ff).AddArgument($tmp).AddArgument($prompt)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
function Voice-Async($ctx, $wav, $prompt) {
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($voiceScript).AddArgument($ctx).AddArgument($wav).AddArgument($voiceState).AddArgument($wExe).AddArgument($wModel).AddArgument($wPort).AddArgument($prompt)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
# 🛰 비행 기록 읽기: DJI 영상 안의 기록(djmd · 장면마다 위치·고도) 또는 옆의 .SRT 파일 → 0.5초마다 [시각, 이륙점 높이(m), 해발 고도(m), 위도, 경도]
Add-Type -TypeDefinition @"
using System; using System.Collections.Generic;
public static class DjiTele {
  static ulong Var(byte[] b, ref int p){ ulong v = 0; int s = 0; while (p < b.Length){ byte x = b[p++]; v |= (ulong)(x & 0x7f) << s; if ((x & 0x80) == 0) break; s += 7; } return v; }
  // 한 장면 기록에서 필요한 값만: 위도·경도(8바이트 소수 두 개가 나란히), 그 형제 칸의 해발 고도(mm 정수), 이륙점 높이(mm 소수)
  static void Walk(byte[] b, int a, int e, int depth, double[] o, ref bool ok){
    int p = a;
    while (p < e){ ulong key = Var(b, ref p); int f = (int)(key >> 3), w = (int)(key & 7); if (f == 0) { ok = false; return; }
      if (w == 0) { Var(b, ref p); }
      else if (w == 1) { if (p + 8 > e) { ok = false; return; } p += 8; }
      else if (w == 5) { if (p + 4 > e) { ok = false; return; } p += 4; }
      else if (w == 2) { int len = (int)Var(b, ref p); if (len < 0 || p + len > e) { ok = false; return; }
        if (depth < 7 && len > 0) { bool sub = true; var keep = (double[])o.Clone(); Probe(b, p, p + len, o); Walk(b, p, p + len, depth + 1, o, ref sub); if (!sub) Array.Copy(keep, o, o.Length); }
        p += len; }
      else { ok = false; return; } }
  }
  // 위치가 든 묶음: 안쪽 묶음(.1)에 위도(.2)·경도(.3), 같은 층에 해발 고도(.2 정수 mm) — 그 위 층의 .5.1 소수가 이륙점 높이(mm)
  static void Probe(byte[] b, int a, int e, double[] o){
    int p = a; double lat = double.NaN, lon = double.NaN;
    while (p < e){ ulong key = Var(b, ref p); int f = (int)(key >> 3), w = (int)(key & 7); if (f == 0) return;
      if (w == 0) Var(b, ref p);
      else if (w == 1) { if (p + 8 > e) return; double d = BitConverter.ToDouble(b, p); p += 8; if (f == 2) lat = d; else if (f == 3) lon = d; }
      else if (w == 5) { if (p + 4 > e) return; p += 4; }
      else if (w == 2) { int len = (int)Var(b, ref p); if (len < 0 || p + len > e) return; p += len; }
      else return; }
    if (!double.IsNaN(lat) && !double.IsNaN(lon) && Math.Abs(lat) <= 90 && Math.Abs(lon) <= 180 && (lat != 0 || lon != 0)) { o[2] = lat; o[3] = lon; }
  }
  // 위치 묶음의 부모(.3.3 같은 곳)에서: .4 = {.1 = 위치, .2 = 해발 mm}, .5 = {.1 = 이륙점 높이 mm}
  static void Alt(byte[] b, int a, int e, int depth, double[] o){
    int p = a;
    while (p < e){ ulong key = Var(b, ref p); int f = (int)(key >> 3), w = (int)(key & 7); if (f == 0) return;
      if (w == 0) Var(b, ref p);
      else if (w == 1) { if (p + 8 > e) return; p += 8; }
      else if (w == 5) { if (p + 4 > e) return; p += 4; }
      else if (w == 2) { int len = (int)Var(b, ref p); if (len < 0 || p + len > e) return;
        if (f == 4 && depth > 0) { int q = p; double abs = double.NaN; bool gps = false; while (q < p + len){ ulong k2 = Var(b, ref q); int f2 = (int)(k2 >> 3), w2 = (int)(k2 & 7); if (f2 == 0) break;
            if (w2 == 0) { ulong v = Var(b, ref q); if (f2 == 2) abs = (long)v / 1000.0; } else if (w2 == 1) q += 8; else if (w2 == 5) q += 4; else if (w2 == 2) { int l2 = (int)Var(b, ref q); if (f2 == 1) gps = true; q += l2; } else break; }
          if (gps && !double.IsNaN(abs)) o[1] = abs; }
        if (f == 5 && depth > 0) { int q = p; while (q < p + len){ ulong k2 = Var(b, ref q); int f2 = (int)(k2 >> 3), w2 = (int)(k2 & 7); if (f2 == 0) break;
            if (w2 == 5) { float v = BitConverter.ToSingle(b, q); q += 4; if (f2 == 1 && Math.Abs(v) < 2e7) o[0] = v / 1000.0; } else if (w2 == 0) Var(b, ref q); else if (w2 == 1) q += 8; else if (w2 == 2) { int l2 = (int)Var(b, ref q); q += l2; } else break; } }
        if (depth < 6) Alt(b, p, p + len, depth + 1, o);
        p += len; }
      else return; }
  }
  // 반환: 0.5초마다 한 줄 "t,rel,abs,lat,lon" (없으면 NaN)
  public static string[] Read(byte[] data, int[] sizes, double[] pts){
    var res = new List<string>(); int off = 0; double next = 0;
    for (int i = 0; i < sizes.Length && off + sizes[i] <= data.Length; i++){
      double t = pts[i];
      if (t + 1e-6 >= next){ var o = new double[]{ double.NaN, double.NaN, double.NaN, double.NaN }; bool ok = true;
        Walk(data, off, off + sizes[i], 0, o, ref ok); Alt(data, off, off + sizes[i], 0, o);
        if (!double.IsNaN(o[2]) || !double.IsNaN(o[0])) res.Add(string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:0.##},{1:0.##},{2:0.##},{3:0.#######},{4:0.#######}", t, o[0], o[1], o[2], o[3]));
        next = t + 0.5; }
      off += sizes[i]; }
    return res.ToArray();
  }
}
"@
$teleDir = Join-Path $outDir '.비행기록'
$teleScript = {
  param($ctx, $src, $ffPath, $fpPath, $cacheJson)
  $res = $ctx.Response
  function Reply($obj) { $b = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 4)); $res.StatusCode = 200; $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $b.Length; $res.OutputStream.Write($b, 0, $b.Length); $res.OutputStream.Close() }
  try {
    $inv = [Globalization.CultureInfo]::InvariantCulture; $rows = @(); $kind = ''
    # ① 옆의 .SRT (예전 DJI 드론)
    $srt = [IO.Path]::ChangeExtension($src, '.SRT'); if (-not (Test-Path -LiteralPath $srt)) { $srt = [IO.Path]::ChangeExtension($src, '.srt') }
    if (Test-Path -LiteralPath $srt) {
      $txt = [IO.File]::ReadAllText($srt); $kind = 'srt'; $next = 0.0
      foreach ($blk in ($txt -split "(\r?\n){2,}")) {
        if ($blk -notmatch '(\d+):(\d+):(\d+)[,.](\d+)\s*-->') { continue }
        $t = [int]$matches[1]*3600 + [int]$matches[2]*60 + [int]$matches[3] + [int]$matches[4]/1000.0; if ($t + 1e-6 -lt $next) { continue }; $next = $t + 0.5
        $g = { param($re) if ($blk -match $re) { [double]::Parse($matches[1], $inv) } else { [double]::NaN } }
        $lat = & $g 'lati?tude\s*:\s*(-?[\d.]+)'; $lon = & $g 'long[a-z]*\s*:\s*(-?[\d.]+)'   # 에어2의 「longtitude」 오타도
        if ([double]::IsNaN($lat)) { if ($blk -match 'GPS\s*\(\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)') { $lon = [double]::Parse($matches[1], $inv); $lat = [double]::Parse($matches[2], $inv) } }
        $rel = & $g 'rel_alt\s*:\s*(-?[\d.]+)'; if ([double]::IsNaN($rel)) { $rel = & $g '\bH\s*[:]?\s*(-?[\d.]+)\s*m\b' }; if ([double]::IsNaN($rel)) { $rel = & $g 'BAROMETER\s*:\s*(-?[\d.]+)' }; if ([double]::IsNaN($rel)) { $rel = & $g '\[\s*altitude\s*:\s*(-?[\d.]+)' }
        $abs = & $g 'abs_alt\s*:\s*(-?[\d.]+)'
        $rows += ,@([Math]::Round($t, 2), $rel, $abs, $lat, $lon)
      }
    } else {
      # ② 영상 안의 기록 (요즘 DJI 드론: djmd)
      $tmpB = [IO.Path]::GetTempFileName()
      $si = & $fpPath -v error -show_entries stream=index,codec_tag_string -of csv=p=0 "$src" 2>$null
      $idx = ($si | Where-Object { $_ -match ',djmd$' } | Select-Object -First 1) -replace ',.*$', ''
      if ($idx -eq $null -or $idx -eq '') { Reply @{ ok = $false; error = 'none' }; return }
      $p = Start-Process -FilePath $ffPath -ArgumentList @('-v', 'error', '-y', '-i', "`"$src`"", '-map', "0:$idx", '-c', 'copy', '-f', 'data', "`"$tmpB`"") -WindowStyle Hidden -PassThru -Wait
      $pk = & $fpPath -v error -select_streams $idx -show_packets -show_entries packet=pts_time,size -of csv=p=0 "$src" 2>$null
      $sizes = New-Object 'System.Collections.Generic.List[int]'; $pts = New-Object 'System.Collections.Generic.List[double]'
      foreach ($l in $pk) { $a = $l -split ','; if ($a.Count -ge 2) { $pts.Add([double]::Parse($a[0], $inv)); $sizes.Add([int]$a[1]) } }
      $lines = [DjiTele]::Read([IO.File]::ReadAllBytes($tmpB), $sizes.ToArray(), $pts.ToArray()); Remove-Item $tmpB -Force -ErrorAction SilentlyContinue
      $kind = 'djmd'
      foreach ($l in $lines) { $a = $l -split ','; $rows += ,@($a | ForEach-Object { if ($_ -eq 'NaN' -or $_ -eq '') { [double]::NaN } else { [double]::Parse($_, $inv) } }) }
    }
    if (-not $rows.Count) { Reply @{ ok = $false; error = 'empty' }; return }
    $clean = @($rows | ForEach-Object { ,@($_ | ForEach-Object { if ([double]::IsNaN([double]$_)) { $null } else { $_ } }) })
    $obj = @{ ok = $true; kind = $kind; rows = $clean }
    try { $j = ($obj | ConvertTo-Json -Compress -Depth 4); [IO.File]::WriteAllText($cacheJson, $j, (New-Object Text.UTF8Encoding($false))) } catch {}
    Reply $obj
  } catch { try { Reply @{ ok = $false; error = "$_" } } catch {} }
}
function Tele-Async($ctx, $src, $cacheJson) {
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($teleScript).AddArgument($ctx).AddArgument($src).AddArgument($ff).AddArgument($fp).AddArgument($cacheJson)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
# 🎞 고화질 저장을 빠르게: 영상의 한 구간을 ffmpeg가 차례로 풀어서 장면(YUV) 그대로 이어 보냄 → 편집기가 장면마다 찾아갈 필요가 없음
$framesScript = {
  param($ctx, $ffPath, $src, $ss, $dur, $w, $h)
  $res = $ctx.Response; $p = $null
  try {
    $vf = if ($w -gt 0 -and $h -gt 0) { "scale=${w}:${h}:flags=bicubic,format=yuv420p" } else { 'format=yuv420p' }
    $a = "-v error -nostdin -ss $ss -i `"$src`" -t $dur -map 0:v:0 -an -vf $vf -f rawvideo -"
    $psi = New-Object Diagnostics.ProcessStartInfo $ffPath, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($psi); [void]$p.StandardError.ReadToEndAsync()
    $res.StatusCode = 200; $res.ContentType = 'application/octet-stream'; $res.SendChunked = $true
    $src2 = $p.StandardOutput.BaseStream; $buf = New-Object byte[] 1MB
    while (($n = $src2.Read($buf, 0, $buf.Length)) -gt 0) { $wt = $res.OutputStream.WriteAsync($buf, 0, $n); if (-not $wt.Wait(8000)) { break } }   # 받는 쪽이 8초 넘게 안 받으면 그만 (연결을 붙잡지 않게)
  } catch {} finally { try { if ($p -and -not $p.HasExited) { $p.Kill() } } catch {}; try { $res.OutputStream.Close() } catch {} }
}
function Frames-Async($ctx, $src, $ss, $dur, $w, $h) {
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($framesScript).AddArgument($ctx).AddArgument($ff).AddArgument($src).AddArgument($ss).AddArgument($dur).AddArgument($w).AddArgument($h)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
function Prune-Streams { for ($i = $streamJobs.Count - 1; $i -ge 0; $i--) { $sj = $streamJobs[$i]; if ($sj.h.IsCompleted) { try { [void]$sj.ps.EndInvoke($sj.h) } catch {}; $sj.ps.Dispose(); $streamJobs.RemoveAt($i) } } }
function Stream-Async($ctx, $p) {
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($streamScript).AddArgument($ctx).AddArgument($p)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
# 🏆 완성 영상 보관함: 「완성된_영상」 폴더 안의 영상 파일만 이름으로 찾음 (폴더 밖은 절대 안 됨)
$doneMeta = Join-Path $doneDir '.보관함.json'
function Done-File($name) {
  $nm = [IO.Path]::GetFileName([string]$name); if (-not $nm -or $nm -notmatch '\.(mp4|webm|mov)$') { return $null }
  $p = Join-Path $doneDir $nm; if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }; return $null
}
function Read-DoneMeta { if (Test-Path -LiteralPath $doneMeta) { try { $o = [IO.File]::ReadAllText($doneMeta, [Text.Encoding]::UTF8) | ConvertFrom-Json; if ($o) { return $o } } catch {} }; return (New-Object PSObject) }
function Write-DoneMeta($o) { if (Test-Path -LiteralPath $doneMeta) { try { (Get-Item -LiteralPath $doneMeta -Force).Attributes = 'Normal' } catch {} }; [IO.File]::WriteAllText($doneMeta, ($o | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false)); try { (Get-Item -LiteralPath $doneMeta -Force).Attributes = 'Hidden' } catch {} }
function ReadBody($req) { $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8); $t = $sr.ReadToEnd(); $sr.Close(); return $t }

# ===== 🔒 비밀번호 잠금 =====
# - 비밀번호 자체는 어디에도 저장하지 않고, PBKDF2-SHA256(20만 번)으로 만든 확인값만 「작업저장\.잠금.json」에 저장
# - 비밀번호가 맞아야 편집기 화면·작업 파일·영상 파일을 열 수 있음 (세션 쿠키)
# - 작업 저장 파일(*.vpe.json)은 비밀번호로 만든 열쇠로 암호화(AES-256 + HMAC-SHA256)
$pwFile = Join-Path $projDir '.잠금.json'
$pwInfo = $null; if (Test-Path -LiteralPath $pwFile) { try { $pwInfo = Get-Content -LiteralPath $pwFile -Raw -Encoding utf8 | ConvertFrom-Json } catch {} }
$sessions = New-Object 'System.Collections.Generic.HashSet[string]'
$keys = $null; $fails = 0; $waitUntil = Get-Date
function New-Rand($n) { $b = New-Object byte[] $n; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); return $b }
function Derive($pw, [byte[]]$salt, [int]$iter) {
  $k = New-Object Security.Cryptography.Rfc2898DeriveBytes($pw, $salt, $iter, [Security.Cryptography.HashAlgorithmName]::SHA256)
  $all = $k.GetBytes(96); $k.Dispose()
  return @{ verify = $all[0..31]; enc = [byte[]]$all[32..63]; mac = [byte[]]$all[64..95] }
}
function Same([byte[]]$a, [byte[]]$b) { if ($a.Length -ne $b.Length) { return $false }; $d = 0; for ($i = 0; $i -lt $a.Length; $i++) { $d = $d -bor ($a[$i] -bxor $b[$i]) }; return $d -eq 0 }
function Check-Pw($pw) { if (-not $pwInfo -or -not $pw) { return $null }; $d = Derive $pw ([Convert]::FromBase64String($pwInfo.salt)) ([int]$pwInfo.iter); if (Same ([byte[]]$d.verify) ([Convert]::FromBase64String($pwInfo.verify))) { return $d }; return $null }
function Enc-Text([string]$txt, $k) {
  $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.enc; $aes.GenerateIV(); $aes.Mode = 'CBC'
  $pt = [Text.Encoding]::UTF8.GetBytes($txt); $ct = $aes.CreateEncryptor().TransformFinalBlock($pt, 0, $pt.Length)
  $body = [byte[]]($aes.IV + $ct); $h = New-Object Security.Cryptography.HMACSHA256 (, $k.mac); $mac = $h.ComputeHash($body)
  return "VPEENC1`n" + [Convert]::ToBase64String([byte[]]($body + $mac))
}
function Dec-Text([string]$s, $k) {
  if (-not $s.StartsWith("VPEENC1")) { return $s }          # 암호화 안 된 파일은 그대로
  if (-not $k) { return $null }
  $all = [Convert]::FromBase64String($s.Substring(8).Trim()); if ($all.Length -lt 64) { return $null }
  $body = [byte[]]$all[0..($all.Length - 33)]; $mac = [byte[]]$all[($all.Length - 32)..($all.Length - 1)]
  $h = New-Object Security.Cryptography.HMACSHA256 (, $k.mac); if (-not (Same ($h.ComputeHash($body)) $mac)) { return $null }
  $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.enc; $aes.Mode = 'CBC'; $aes.IV = [byte[]]$body[0..15]
  $pt = $aes.CreateDecryptor().TransformFinalBlock($body, 16, $body.Length - 16); return [Text.Encoding]::UTF8.GetString($pt)
}
function Write-Proj($path, [string]$txt) { $out = $(if ($pwInfo -and $keys) { Enc-Text $txt $keys } else { $txt }); $tmpf = "$path.tmp"; [IO.File]::WriteAllText($tmpf, $out, (New-Object Text.UTF8Encoding $false)); Move-Item -LiteralPath $tmpf -Destination $path -Force }

# ===== ☁ 클라우드 백업(선택) · 👥 팀 작업 폴더 =====
# - 따로 로그인하지 않음: 이 컴퓨터에 이미 설치된 OneDrive·구글 드라이브·Dropbox·iCloud 폴더에 「복사」만 하면, 그 프로그램이 알아서 인터넷에 올림
# - 비밀번호가 걸려 있으면 작업 파일은 암호화된 그대로 올라감 · 편집기가 쓰는 곳은 고른 폴더 안의 「영상편집기_백업」「영상편집기_팀작업」 폴더뿐
$linkFile = Join-Path $projDir '.연결설정.json'
$link = @{ cloud = ''; cloudDone = $false; team = ''; me = ''; upd = '' }
if (Test-Path -LiteralPath $linkFile) { try { $o = Get-Content -LiteralPath $linkFile -Raw -Encoding utf8 | ConvertFrom-Json; foreach ($k in @('cloud', 'cloudDone', 'team', 'me', 'upd')) { if ($null -ne $o.$k) { $link[$k] = $o.$k } } } catch {} }
function Save-Link { New-Item -ItemType Directory -Force $projDir | Out-Null; [IO.File]::WriteAllText($linkFile, ($link | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false)) }
function Cloud-Roots {
  $r = New-Object System.Collections.ArrayList
  $cand = @(@('OneDrive', $env:OneDrive), @('OneDrive (학교·회사)', $env:OneDriveCommercial), @('OneDrive (개인)', $env:OneDriveConsumer), @('Dropbox', (Join-Path $env:USERPROFILE 'Dropbox')), @('iCloud Drive', (Join-Path $env:USERPROFILE 'iCloudDrive')))
  foreach ($d in [IO.DriveInfo]::GetDrives()) { try { if ($d.DriveType -ne 'Network' -and $d.IsReady) { foreach ($n in @('내 드라이브', 'My Drive')) { $cand += , @('Google 드라이브', (Join-Path $d.RootDirectory.FullName $n)) } } } catch {} }
  foreach ($p in $cand) { if ($p[1] -and (Test-Path -LiteralPath $p[1] -PathType Container) -and -not ($r | Where-Object { $_.path -eq $p[1] })) { [void]$r.Add(@{ kind = $p[0]; path = [string]$p[1] }) } }
  return , $r.ToArray()
}
# 고를 수 있는 폴더인지 (윈도우·프로그램 폴더 같은 시스템 폴더는 안 됨)
function Ok-Folder($p) {
  if (-not $p) { return $null }
  try { $full = [IO.Path]::GetFullPath([string]$p).TrimEnd('\') } catch { return $null }
  if (-not (Test-Path -LiteralPath $full -PathType Container)) { return $null }
  foreach ($bad in @($env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, (Join-Path $env:USERPROFILE 'AppData'))) { if ($bad -and ($full + '\').StartsWith($bad.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null } }
  return $full
}
function Cloud-Dir { if ($link.cloud -and (Test-Path -LiteralPath $link.cloud -PathType Container)) { return (Join-Path $link.cloud '영상편집기_백업') }; return $null }
function Team-Dir { if ($link.team -and (Test-Path -LiteralPath $link.team -PathType Container)) { return (Join-Path $link.team '영상편집기_팀작업') }; return $null }
$cloudState = [hashtable]::Synchronized(@{ last = ''; busy = 0; err = '' })
# ===== 🔄 자동 업데이트 (공유받은 편집기): 팀 작업 폴더·고른 폴더에 만든 사람이 서명해 올린 새 버전이 있으면 스스로 설치 =====
$updScriptF = Join-Path $PSScriptRoot 'updater.ps1'
$updState = [hashtable]::Synchronized(@{ busy = $false; state = ''; why = ''; checked = ''; to = ''; notes = '' })
$nextUpd = (Get-Date).AddSeconds(20)
$updJob = {
  param($upd, $root, $srcs, $proj, $st)
  try { . $upd; $r = Invoke-VpeUpdate -Root $root -Sources $srcs -StateDir $proj; foreach ($k in @('state', 'why', 'checked', 'to', 'notes')) { $st[$k] = [string]$r[$k] } }
  catch { $st.state = 'error'; $st.why = "$_" } finally { $st.busy = $false }
}
function Start-UpdCheck {
  if ($updState.busy -or -not (Test-Path -LiteralPath $updScriptF)) { return }
  . $updScriptF
  $srcs = Get-VpeUpdSources $root (Team-Dir) $(if ($link.upd -and (Test-Path -LiteralPath $link.upd -PathType Container)) { $link.upd } else { $null })
  if (-not $srcs.Count) { $updState.state = 'nosrc'; $updState.checked = (Get-Date).ToString('yyyy-MM-dd HH:mm'); return }
  $updState.busy = $true; Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($updJob).AddArgument($updScriptF).AddArgument($root).AddArgument([string[]]$srcs).AddArgument($projDir).AddArgument($updState)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
# 큰 파일 복사는 따로 일하는 일꾼에게 (편집기가 기다리지 않게)
$copyScript = {
  param($pairs, $st)
  foreach ($pr in $pairs) {
    try {
      $st.busy++
      $src = $pr[0]; $dst = $pr[1]
      if ((Test-Path -LiteralPath $dst) -and (Get-Item -LiteralPath $dst).Length -eq (Get-Item -LiteralPath $src).Length) { continue }
      New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
      [IO.File]::Copy($src, "$dst.copying", $true); Move-Item -LiteralPath "$dst.copying" -Destination $dst -Force
      $st.last = (Get-Date).ToString('yyyy-MM-dd HH:mm'); $st.done = [int]$st.done + 1
    } catch { $st.err = "$_" } finally { $st.busy-- }
  }
}
function Copy-Async($pairs, $st) {
  if (-not $pairs -or -not $pairs.Count) { return }
  Prune-Streams
  $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
  [void]$ps.AddScript($copyScript).AddArgument($pairs).AddArgument($st)
  [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
}
# 작업 저장 직후: 클라우드 폴더에도 같은 파일을 한 벌 (작은 파일이라 바로)
function Cloud-Project($latest, $dated) {
  $cd = Cloud-Dir; if (-not $cd) { return }
  try {
    $pd = Join-Path $cd '작업저장'; New-Item -ItemType Directory -Force $pd | Out-Null
    Copy-Item -LiteralPath $latest -Destination (Join-Path $pd (Split-Path $latest -Leaf)) -Force
    if ($dated -and (Test-Path -LiteralPath $dated)) { Copy-Item -LiteralPath $dated -Destination (Join-Path $pd (Split-Path $dated -Leaf)) -Force }
    if (Test-Path -LiteralPath $pwFile) { Copy-Item -LiteralPath $pwFile -Destination (Join-Path $pd '.잠금.json') -Force }   # 암호를 푸는 확인값 (비밀번호 자체는 없음)
    $h = Get-ChildItem -LiteralPath $pd -Filter '자동저장_20*.vpe.json' | Sort-Object LastWriteTime
    if ($h.Count -gt 40) { $h | Select-Object -First ($h.Count - 40) | Remove-Item -Force }
    $cloudState.last = (Get-Date).ToString('yyyy-MM-dd HH:mm'); $cloudState.err = ''
  } catch { $cloudState.err = "$_"; Log "cloud backup error: $_" }
}
function Cloud-Done($p) { $cd = Cloud-Dir; if ($cd -and $link.cloudDone -and $p -and (Test-Path -LiteralPath $p)) { Copy-Async @(, @($p, (Join-Path (Join-Path $cd '완성된_영상') (Split-Path $p -Leaf)))) $cloudState } }
$teamState = [hashtable]::Synchronized(@{ last = ''; busy = 0; err = ''; done = 0 })
# 폴더 고르기 창 (윈도우 기본 창, 따로 띄워서 편집기가 멈추지 않게)
function Start-PickFolder {
  # 이미 열려 있는 고르기 창이 있으면 새로 열지 않고 그것을 씀 (여러 번 눌러도 하나만)
  foreach ($j in @($jobs.Values)) { if ($j.pick -and $j.proc -and -not $j.proc.HasExited) { return $j.id } }
  $id = [guid]::NewGuid().ToString('N'); $outf = Join-Path $tmp "$id.pick"
  # 탐색기처럼 생긴 창(왼쪽에 구글 드라이브·OneDrive·USB가 보임)으로 폴더 고르기
  # ※ 주인 창을 두면 창이 안 뜨고, 「숨김」으로 시작하면 첫 창이 숨겨져서 → 주인 없이 띄운 뒤, 뜨자마자 맨 앞(항상 위)으로 끌어올림
  $cmd = @"
Add-Type -AssemblyName System.Windows.Forms
Add-Type 'using System; using System.Runtime.InteropServices; public class PkW { [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c, string t); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }'
`$title = '팀원과 함께 쓸 폴더 안으로 들어간 뒤 「열기」를 누르세요'
`$t = New-Object System.Windows.Forms.Timer; `$t.Interval = 150; `$n = 0
`$t.Add_Tick({ `$h = [PkW]::FindWindow('#32770', `$title); if (`$h -ne [IntPtr]::Zero) { [void][PkW]::SetWindowPos(`$h, [IntPtr](-1), 0, 0, 0, 0, 0x43); [void][PkW]::SetForegroundWindow(`$h); `$script:n++; if (`$script:n -ge 3) { `$t.Stop() } } })
`$t.Start()
`$d = New-Object System.Windows.Forms.OpenFileDialog; `$d.Title = `$title
`$d.ValidateNames = `$false; `$d.CheckFileExists = `$false; `$d.CheckPathExists = `$true; `$d.FileName = '이 폴더 고르기'; `$d.Filter = '폴더|*.폴더없음'
`$out = ''; if (`$d.ShowDialog() -eq 'OK') { `$out = [IO.Path]::GetDirectoryName(`$d.FileName) }
[IO.File]::WriteAllText('$outf', `$out, [Text.Encoding]::UTF8)
"@
  $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cmd))
  $psi = New-Object Diagnostics.ProcessStartInfo 'powershell.exe', "-NoProfile -STA -EncodedCommand $enc"; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
  $p = [Diagnostics.Process]::Start($psi)
  $jobs[$id] = @{ id = $id; pick = $outf; proc = $p; state = 'running' }
  return $id
}

# ===== 📱 같은 와이파이의 태블릿·Mac·다른 노트북에서 열기 (선택 · 처음엔 꺼져 있음) =====
# - 이 PC에서 켤 때만 열림 · 6자리 확인 번호 · 집·학교 같은 내부 네트워크 주소만 · 2시간 뒤 저절로 꺼짐
# - 들어온 요청은 이 PC 안의 도우미(127.0.0.1)로 그대로 전달 → 보안 검사·비밀번호 잠금은 똑같이 적용
# - 원격에서는 비밀번호·클라우드·팀 설정, PC 폴더 열기 등 「이 PC를 바꾸는 일」은 막음
$lanType = @'
using System; using System.IO; using System.Net; using System.Net.Sockets; using System.Net.Http; using System.Text;
using System.Threading.Tasks; using System.Collections.Generic; using System.Collections.Concurrent; using System.Security.Cryptography;
public class VpeLan {
  public int Port, Target; public string Pin = ""; public DateTime Until; public volatile bool On; public string PinPage = ""; public bool LoopOnly;
  public int Fails; public DateTime LockUntil; public ConcurrentDictionary<string, DateTime> Seen = new ConcurrentDictionary<string, DateTime>();
  TcpListener L; ConcurrentDictionary<string, byte> Sess = new ConcurrentDictionary<string, byte>(); static HttpClient H;
  static readonly string[] Blocked = { "/api/pw/", "/api/lock", "/api/cloud/set", "/api/team/set", "/api/pickfolder", "/api/lan/", "/api/reveal", "/api/kakao", "/api/clipfile", "/api/mail", "/api/project/reveal", "/api/done/folder", "/api/cloud/open", "/api/team/open", "/api/done/trash", "/api/done/rename", "/api/update/set", "/api/update/check" };
  static readonly HashSet<string> Skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "Host", "Origin", "Referer", "Connection", "Keep-Alive", "Content-Length", "Content-Type", "Transfer-Encoding", "Expect", "Upgrade", "Proxy-Connection", "X-VPE-Remote", "Sec-Fetch-Site", "Sec-Fetch-Mode", "Sec-Fetch-Dest" };
  public void Start() {
    if (H == null) { var h = new HttpClientHandler(); h.UseCookies = false; h.AllowAutoRedirect = false; H = new HttpClient(h); H.Timeout = TimeSpan.FromHours(3); }
    Sess.Clear(); Fails = 0; L = new TcpListener(LoopOnly ? IPAddress.Loopback : IPAddress.Any, Port); L.Start(); On = true; Loop();
  }
  public void Stop() { On = false; Sess.Clear(); try { L.Stop(); } catch { } }
  public int Sessions { get { return Sess.Count; } }
  async void Loop() { while (On) { TcpClient c; try { c = await L.AcceptTcpClientAsync(); } catch { break; } var t = Handle(c); } }
  public static bool PrivateIp(IPAddress a) {
    if (IPAddress.IsLoopback(a)) return true; if (a.IsIPv4MappedToIPv6) a = a.MapToIPv4(); if (a.AddressFamily != AddressFamily.InterNetwork) return false;
    var b = a.GetAddressBytes(); return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168) || (b[0] == 169 && b[1] == 254);
  }
  static string Rand(int n) { var b = new byte[n]; using (var r = RandomNumberGenerator.Create()) r.GetBytes(b); return BitConverter.ToString(b).Replace("-", "").ToLower(); }
  static bool SameStr(string a, string b) { if (a == null || b == null || a.Length != b.Length) return false; int d = 0; for (int i = 0; i < a.Length; i++) d |= a[i] ^ b[i]; return d == 0; }
  static async Task WriteSimple(Stream s, int code, string type, string body, string extra) {
    var bb = Encoding.UTF8.GetBytes(body ?? "");
    var hd = "HTTP/1.1 " + code + " X\r\nContent-Type: " + type + "\r\nContent-Length: " + bb.Length + "\r\nCache-Control: no-store\r\nX-Frame-Options: DENY\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n" + (extra ?? "") + "\r\n";
    var hb = Encoding.ASCII.GetBytes(hd); await s.WriteAsync(hb, 0, hb.Length); await s.WriteAsync(bb, 0, bb.Length);
  }
  class Body : Stream {   // 머리 뒤에 이미 읽힌 부분 + 나머지를 정해진 길이만큼
    Stream S; byte[] Pre; int PreOff, PreLen; long Left;
    public Body(Stream s, byte[] pre, int off, int len, long total) { S = s; Pre = pre; PreOff = off; PreLen = Math.Min(len, (int)Math.Min(total, int.MaxValue)); Left = total; }
    public override int Read(byte[] buf, int off, int cnt) {
      if (Left <= 0) return 0; if (cnt > Left) cnt = (int)Left;
      if (PreLen > 0) { int n = Math.Min(cnt, PreLen); Buffer.BlockCopy(Pre, PreOff, buf, off, n); PreOff += n; PreLen -= n; Left -= n; return n; }
      int r = S.Read(buf, off, cnt); if (r > 0) Left -= r; return r;
    }
    public override bool CanRead { get { return true; } } public override bool CanSeek { get { return false; } } public override bool CanWrite { get { return false; } }
    public override long Length { get { throw new NotSupportedException(); } } public override long Position { get { throw new NotSupportedException(); } set { throw new NotSupportedException(); } }
    public override void Flush() { } public override long Seek(long o, SeekOrigin so) { throw new NotSupportedException(); } public override void SetLength(long v) { throw new NotSupportedException(); } public override void Write(byte[] b, int o, int c) { throw new NotSupportedException(); }
  }
  static async Task Drain(Stream ns, int pre, long clen) { long left = Math.Min(clen, 8L << 20) - pre; var b = new byte[65536]; while (left > 0) { int r = await ns.ReadAsync(b, 0, (int)Math.Min(b.Length, left)); if (r <= 0) break; left -= r; } }
  async Task Handle(TcpClient c) {
    using (c) {
      try {
        c.NoDelay = true; var ip = ((IPEndPoint)c.Client.RemoteEndPoint).Address; var ns = c.GetStream();
        if (!On || DateTime.Now > Until || !PrivateIp(ip)) return;
        var buf = new byte[65536]; int got = 0, hEnd = -1;
        while (hEnd < 0) { int r = await ns.ReadAsync(buf, got, buf.Length - got); if (r <= 0) return; got += r; for (int i = Math.Max(3, got - r - 3); i < got; i++) if (buf[i - 3] == 13 && buf[i - 2] == 10 && buf[i - 1] == 13 && buf[i] == 10) { hEnd = i + 1; break; } if (hEnd < 0 && got >= buf.Length) return; }
        var lines = Encoding.UTF8.GetString(buf, 0, hEnd).Split(new[] { "\r\n" }, StringSplitOptions.None); var rl = lines[0].Split(' '); if (rl.Length < 3) return;
        string method = rl[0], target = rl[1]; var hs = new List<KeyValuePair<string, string>>(); string cookie = "", ctype = null; long clen = 0; bool chunked = false;
        for (int i = 1; i < lines.Length; i++) { int k = lines[i].IndexOf(':'); if (k <= 0) continue; var n = lines[i].Substring(0, k).Trim(); var v = lines[i].Substring(k + 1).Trim(); hs.Add(new KeyValuePair<string, string>(n, v));
          if (n.Equals("Cookie", StringComparison.OrdinalIgnoreCase)) cookie = v; else if (n.Equals("Content-Type", StringComparison.OrdinalIgnoreCase)) ctype = v; else if (n.Equals("Content-Length", StringComparison.OrdinalIgnoreCase)) long.TryParse(v, out clen); else if (n.Equals("Transfer-Encoding", StringComparison.OrdinalIgnoreCase) && v.ToLower().Contains("chunked")) chunked = true; }
        string path = target; int qi = path.IndexOf('?'); if (qi >= 0) path = path.Substring(0, qi);
        string sid = null; foreach (var part in cookie.Split(';')) { var p = part.Trim(); if (p.StartsWith("vpel=")) sid = p.Substring(5); }
        bool ok = sid != null && Sess.ContainsKey(sid); var ips = ip.ToString(); Seen[ips] = DateTime.Now;
        if (path == "/lan-pin" && method == "POST") {
          if (DateTime.Now < LockUntil) { await WriteSimple(ns, 200, "application/json", "{\"ok\":false,\"wait\":" + (int)(LockUntil - DateTime.Now).TotalSeconds + "}", null); return; }
          var bb = new byte[Math.Min(clen, 200)]; int have = Math.Min(got - hEnd, bb.Length); Buffer.BlockCopy(buf, hEnd, bb, 0, have); while (have < bb.Length) { int r = await ns.ReadAsync(bb, have, bb.Length - have); if (r <= 0) break; have += r; }
          var txt = Encoding.UTF8.GetString(bb, 0, have); var digits = new StringBuilder(); foreach (var ch in txt) if (ch >= '0' && ch <= '9') digits.Append(ch);
          if (SameStr(digits.ToString(), Pin)) { Fails = 0; var ns2 = Rand(16); Sess[ns2] = 1; await WriteSimple(ns, 200, "application/json", "{\"ok\":true}", "Set-Cookie: vpel=" + ns2 + "; Path=/; HttpOnly; SameSite=Strict\r\n"); return; }
          Fails++; if (Fails >= 5) { LockUntil = DateTime.Now.AddMinutes(10); Fails = 0; }
          await WriteSimple(ns, 200, "application/json", "{\"ok\":false}", null); return;
        }
        if (!ok) { await Drain(ns, got - hEnd, clen); if (method == "GET" && (path == "/" || path == "/index.html")) await WriteSimple(ns, 200, "text/html; charset=utf-8", PinPage, null); else await WriteSimple(ns, 401, "text/plain", "pin", null); return; }
        foreach (var b in Blocked) if (path.StartsWith(b, StringComparison.OrdinalIgnoreCase)) { await Drain(ns, got - hEnd, clen); await WriteSimple(ns, 403, "application/json", "{\"ok\":false,\"remote\":true}", null); return; }
        if (chunked) { await WriteSimple(ns, 411, "text/plain", "length required", null); return; }
        var req = new HttpRequestMessage(new HttpMethod(method), "http://127.0.0.1:" + Target + target);
        string cookie2 = string.Join("; ", Array.FindAll(cookie.Split(';'), x => !x.Trim().StartsWith("vpel=")));
        foreach (var h in hs) { if (Skip.Contains(h.Key) || h.Key.StartsWith("Sec-Fetch", StringComparison.OrdinalIgnoreCase)) continue; if (h.Key.Equals("Cookie", StringComparison.OrdinalIgnoreCase)) { if (cookie2.Trim().Length > 0) req.Headers.TryAddWithoutValidation("Cookie", cookie2); continue; } req.Headers.TryAddWithoutValidation(h.Key, h.Value); }
        foreach (var h in hs) if (h.Key.Equals("Origin", StringComparison.OrdinalIgnoreCase)) req.Headers.TryAddWithoutValidation("Origin", "http://127.0.0.1:" + Target);
        req.Headers.TryAddWithoutValidation("X-VPE-Remote", ips);
        if (clen > 0) { req.Content = new StreamContent(new Body(ns, buf, hEnd, got - hEnd, clen), 1 << 20); req.Content.Headers.ContentLength = clen; if (ctype != null) req.Content.Headers.TryAddWithoutValidation("Content-Type", ctype); }
        using (var res = await H.SendAsync(req, HttpCompletionOption.ResponseHeadersRead)) {
          var sb = new StringBuilder(); sb.Append("HTTP/1.1 ").Append((int)res.StatusCode).Append(" X\r\n");
          foreach (var h in res.Headers) { if (h.Key.Equals("Transfer-Encoding", StringComparison.OrdinalIgnoreCase) || h.Key.Equals("Connection", StringComparison.OrdinalIgnoreCase)) continue; foreach (var v in h.Value) sb.Append(h.Key).Append(": ").Append(v).Append("\r\n"); }
          foreach (var h in res.Content.Headers) foreach (var v in h.Value) sb.Append(h.Key).Append(": ").Append(v).Append("\r\n");
          sb.Append("Connection: close\r\n\r\n"); var hb = Encoding.UTF8.GetBytes(sb.ToString()); await ns.WriteAsync(hb, 0, hb.Length);
          using (var rs = await res.Content.ReadAsStreamAsync()) await rs.CopyToAsync(ns, 1 << 18);
        }
      } catch { }
    }
  }
}
'@
$lan = $null
function Lan-Urls($port) { @([Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() | Where-Object { $_.OperationalStatus -eq 'Up' -and $_.NetworkInterfaceType -ne 'Loopback' } | ForEach-Object { $_.GetIPProperties().UnicastAddresses } | Where-Object { $_.Address.AddressFamily -eq 'InterNetwork' -and [VpeLan]::PrivateIp($_.Address) -and -not $_.Address.ToString().StartsWith('169.254') } | ForEach-Object { "http://$($_.Address):$port/" }) }
$lanPinPage = @'
<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>영상·사진 편집기 연결</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0a0d12;color:#e9eef5;font-family:-apple-system,"Apple SD Gothic Neo","Malgun Gothic",sans-serif}
.b{background:#151b23;border:1px solid #252e3a;border-radius:20px;padding:28px;width:min(380px,90vw);text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.6)}
h1{font-size:21px;margin:0 0 6px}p{color:#8b98a8;font-size:14px;line-height:1.6}input{font-size:30px;letter-spacing:.35em;text-align:center;width:100%;box-sizing:border-box;padding:12px;border-radius:12px;border:1px solid #2c3644;background:#0c1016;color:#fff;margin:10px 0}
button{width:100%;font-size:18px;font-weight:bold;padding:14px;border:0;border-radius:12px;background:linear-gradient(135deg,#34d399,#22d3ee);color:#04241a}#m{min-height:22px;color:#ff9aa4;font-size:14px}</style></head>
<body><div class="b"><h1>📱 편집기에 연결</h1><p>편집기가 켜진 PC 화면에 보이는<br><b>6자리 확인 번호</b>를 넣으세요.</p>
<input id="p" inputmode="numeric" maxlength="6" autocomplete="one-time-code" autofocus><div id="m"></div><button id="go">연결하기</button></div>
<script>const go=async()=>{const r=await fetch('/lan-pin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:document.getElementById('p').value})});const j=await r.json();if(j.ok)location.reload();else document.getElementById('m').textContent=j.wait?('잠시 뒤에 다시 해 주세요 ('+j.wait+'초)'):'번호가 달라요. PC 화면의 번호를 확인해 주세요.';};
document.getElementById('go').onclick=go;document.getElementById('p').onkeydown=e=>{if(e.key==='Enter')go();};</script></body></html>
'@
# 비밀번호를 정하거나 바꾸거나 없앨 때: 작업 파일을 모두 새 열쇠로 다시 씀 (풀 수 없는 파일은 건드리지 않음)
function Rewrap($oldK, $newK) {
  $n = 0
  foreach ($f in Get-ChildItem -LiteralPath $projDir -Filter '*.vpe.json' -File -ErrorAction SilentlyContinue) {
    $raw = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8); $plain = Dec-Text $raw $oldK
    if ($null -eq $plain) { continue }
    $out = $(if ($newK) { Enc-Text $plain $newK } else { $plain }); [IO.File]::WriteAllText($f.FullName, $out, (New-Object Text.UTF8Encoding $false)); $n++
  }
  return $n
}
function Has-Session($req) { $c = $req.Cookies['vpes']; return ($c -and $sessions.Contains($c.Value)) }
$lockPage = @'
<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>영상·사진 편집기 - 잠김</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{margin:0;background:#12151b;color:#e8edf3;font-family:"Malgun Gothic",sans-serif;display:flex;align-items:center;justify-content:center;height:100vh}
.box{background:#1b2029;border:1px solid #2c3442;border-radius:14px;padding:30px 34px;width:360px;box-shadow:0 10px 40px #0008}
h1{font-size:22px;margin:0 0 6px}p{color:#9aa7b5;font-size:14px;line-height:1.6;margin:6px 0}
input{width:100%;box-sizing:border-box;font-size:20px;padding:12px;border-radius:9px;border:1px solid #3a4558;background:#0f1218;color:#fff;margin:14px 0 10px}
button{width:100%;font-size:18px;padding:12px;border-radius:9px;border:0;background:#3fb27f;color:#fff;font-weight:bold;cursor:pointer}button:disabled{opacity:.5}
.err{color:#ffb547;min-height:22px;font-size:14px}.hint{background:none;border:0;color:#7fd0ff;font-size:13px;padding:4px;width:auto;font-weight:normal}</style></head>
<body><div class="box"><h1>🔒 영상·사진 편집기</h1><p>비밀번호를 넣어야 열려요.</p>
<form id="f"><input type="password" id="pw" placeholder="비밀번호" autofocus autocomplete="current-password"><div class="err" id="err"></div><button id="go">열기</button></form>
<button class="hint" id="hb" type="button">💡 비밀번호 힌트 보기</button><p id="ht" style="display:none"></p>
<p style="font-size:12px;margin-top:14px">비밀번호를 잊으면 저장된 작업은 열 수 없어요. (영상·사진 원본 파일은 그대로 있어요)</p></div>
<script>
const $=id=>document.getElementById(id);
$('hb').onclick=async()=>{const r=await fetch('/hint');const j=await r.json();$('ht').style.display='';$('ht').textContent=j.hint?('힌트: '+j.hint):'힌트가 없어요.';};
$('f').onsubmit=async e=>{e.preventDefault();$('go').disabled=true;$('err').textContent='확인하는 중…';
 try{const r=await fetch('/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pw:$('pw').value})});const j=await r.json();
 if(j.ok){location.reload();return;}
 $('err').textContent=j.wait?('여러 번 틀려서 '+j.wait+'초 뒤에 다시 해 주세요.'):'비밀번호가 맞지 않아요.';$('pw').value='';$('pw').focus();}
 catch(x){$('err').textContent='문제가 생겼어요. 편집기를 다시 열어 주세요.';}
 $('go').disabled=false;};
setInterval(()=>fetch('/ping').catch(()=>{}),20000);
</script></body></html>
'@

function Probe($path) {
  $info = & $fp -v error -select_streams v:0 -show_entries stream=codec_name,color_transfer,width,height:format=duration -of default=nw=1 "$path" 2>$null
  $o = @{}; foreach ($l in $info) { $k, $v = $l -split '=', 2; if (-not $o.ContainsKey($k)) { $o[$k] = $v } }
  return $o
}
# 🎞 미리보기용 가벼운 사본 (2026-11-15)
#   4K·60프레임·HEVC 10비트 드론 원본을 브라우저가 재생하면서 매 장면 화면에 그리면, 영상 풀기가 못 따라가서 1초에 25번 정도만 그리고 자주 멈칫함
#   (사양이 낮은 노트북일수록 더 심함) → 재생·미리보기만 720p·30프레임 사본으로, 고화질 저장은 지금처럼 원본으로
#   · 장면 찾아가기가 빠르도록 0.5초마다 기준 장면 · 풀기 쉬운 방식(fastdecode) · 한 번에 하나씩, 낮은 우선순위로 (편집을 방해하지 않게)
$proxyDir = Join-Path $env:LOCALAPPDATA '영상사진편집기_미리보기'
New-Item -ItemType Directory -Force $proxyDir | Out-Null
Get-ChildItem $proxyDir -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) -or $_.Name -like '*.part.mp4' } | Remove-Item -Force -ErrorAction SilentlyContinue   # 30일 넘게 안 쓴 사본은 지움
function Start-Proxy($job) {
  $vf = "scale=$($job.tw):$($job.th)"
  if ($job.fps30) { $vf += ',fps=30' }
  if ($job.tm) { $vf += ',zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv' }
  $vf += ',format=yuv420p'
  $hw = $(if ($job.hw) { '-hwaccel auto ' } else { '' })
  Remove-Item -LiteralPath $job.prog -Force -ErrorAction SilentlyContinue
  $a = "-hide_banner -loglevel error -y -nostdin $hw-i `"$($job.src)`" -map 0:v:0 -map 0:a? -vf $vf -c:v libx264 -preset veryfast -tune fastdecode -crf 24 -g 15 -keyint_min 15 -sc_threshold 0 -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 -c:a aac -b:a 128k -movflags +faststart -progress `"$($job.prog)`" `"$($job.out)`""
  $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a
  $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
  $pr = [Diagnostics.Process]::Start($psi)
  try { $pr.PriorityClass = 'BelowNormal' } catch {}
  $job.proc = $pr; $job.errTask = $pr.StandardError.ReadToEndAsync()
  Log "proxy start $($job.id) $($job.tw)x$($job.th) fps30=$($job.fps30) tonemap=$($job.tm) hw=$($job.hw)"
}
function Start-Ffmpeg($job, [bool]$tonemap) {
  $w = [int]$job.w; $h = [int]$job.h
  $scale = if ([math]::Min($w, $h) -le 1080) { 'scale=trunc(iw/2)*2:trunc(ih/2)*2' } elseif ($h -gt $w) { 'scale=1080:-2' } else { 'scale=-2:1080' }
  $vf = if ($tonemap) { "$scale,zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p" } else { "$scale,format=yuv420p" }
  $a = "-hide_banner -loglevel error -y -nostdin -i `"$($job.inp)`" -map 0:v:0 -map 0:a? -vf $vf -c:v libx264 -preset veryfast -force_key_frames expr:gte(t,n_forced*1) -sc_threshold 0 -crf 18 -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 -c:a aac -b:a 192k -movflags +faststart -progress `"$($job.prog)`" `"$($job.out)`""
  $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a
  $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
  $p = [Diagnostics.Process]::Start($psi)
  $job.proc = $p; $job.errTask = $p.StandardError.ReadToEndAsync(); $job.tonemap = $tonemap
  Log "ffmpeg start $($job.id) tonemap=$tonemap"
}
function Start-Hyper($job) {
  $inv = [Globalization.CultureInfo]::InvariantCulture
  $ss = $job.t0.ToString('0.###', $inv); $tt = $job.len.ToString('0.###', $inv)
  # 필요한 장면만 먼저 고름: R장마다 앞쪽 K장 (나머지는 처리하지 않아 훨씬 빠름)
  $R = $job.R; $K = $job.K
  $pick = "select='lt(mod(n\,$R)\,$K)'"
  if ($job.stage -eq 1 -and $job.stab) {
    # 1단계: 흔들림 분석 (720p로 가볍게)
    $a = "-hide_banner -loglevel error -y -nostdin -ss $ss -t $tt -i `"$($job.src)`" -vf $pick,scale=-2:720,vidstabdetect=shakiness=5:accuracy=9:result=$($job.trf) -f null - -progress `"$($job.prog1)`""
  } else {
    $job.stage = 2
    $vf = "$pick,scale=-2:1080"
    if ($job.stab -and (Test-Path (Join-Path $tmp $job.trf))) { $vf += ",vidstabtransform=input=$($job.trf):smoothing=12:zoom=3,unsharp=5:5:0.5" }
    if ($K -gt 1) { $vf += ",tmix=frames=$K,select='eq(mod(n\,$K)\,$($K-1))'" }   # K장을 섞어 1장으로 (부드러운 잔상)
    $vf += ",setpts=N/(30*TB),format=yuv420p"
    $a = "-hide_banner -loglevel error -y -nostdin -ss $ss -t $tt -i `"$($job.src)`" -map 0:v:0 -an -vf $vf -r 30 -c:v libx264 -preset veryfast -force_key_frames expr:gte(t,n_forced*1) -sc_threshold 0 -crf 19 -movflags +faststart -progress `"$($job.prog)`" `"$($job.out)`""
  }
  $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a
  $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true; $psi.WorkingDirectory = $tmp
  $job.proc = [Diagnostics.Process]::Start($psi); $job.errTask = $job.proc.StandardError.ReadToEndAsync()
  Log ("hyperlapse {0} stage {1} x{2:N1} every={3} mix={4} stab={5}" -f $job.id, $job.stage, $job.F, $job.R, $job.K, $job.stab)
}
# ⏪ 거꾸로 재생: 2초씩 잘라 각각 뒤집은 뒤, 뒤 조각부터 이어 붙임 (메모리를 적게 써서 긴 구간도 됨)
function Start-Rev($job) {
  $inv = [Globalization.CultureInfo]::InvariantCulture
  if ($job.k -lt $job.n) {
    $a0 = $job.t0 + $job.k * 2.0; $len = [math]::Min(2.0, $job.t0 + $job.len - $a0)
    $part = Join-Path $tmp ("{0}_r{1:D4}.mp4" -f $job.id, $job.k); $job.parts += $part
    $a = "-hide_banner -loglevel error -y -nostdin -ss $($a0.ToString('0.###', $inv)) -t $($len.ToString('0.###', $inv)) -i `"$($job.src)`" -map 0:v:0 -an -vf reverse,format=yuv420p -c:v libx264 -preset veryfast -crf 17 -force_key_frames expr:gte(t,n_forced*1) -sc_threshold 0 -video_track_timescale 30000 `"$part`""
  } else {
    $lst = Join-Path $tmp "$($job.id)_list.txt"; $lines = @(); for ($i = $job.parts.Count - 1; $i -ge 0; $i--) { $lines += "file '" + $job.parts[$i].Replace("'", "'\''") + "'" }
    [IO.File]::WriteAllLines($lst, $lines); $job.concat = $true
    $a = "-hide_banner -loglevel error -y -nostdin -f concat -safe 0 -i `"$lst`" -c copy -movflags +faststart `"$($job.out)`""
  }
  $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
  $job.proc = [Diagnostics.Process]::Start($psi); $job.errTask = $job.proc.StandardError.ReadToEndAsync()
}
# 🎥 흔들림 줄이기: 1단계 흔들림 재기(vidstabdetect) → 2단계 반대로 움직여 바로잡기(vidstabtransform)
function Start-Stab($job) {
  $inv = [Globalization.CultureInfo]::InvariantCulture; $ss = $job.t0.ToString('0.###', $inv); $tt = $job.len.ToString('0.###', $inv)
  if ($job.stage -eq 1) { $a = "-hide_banner -loglevel error -y -nostdin -ss $ss -t $tt -i `"$($job.src)`" -vf vidstabdetect=shakiness=7:accuracy=12:result=$($job.trf) -f null - -progress `"$($job.prog1)`"" }
  else { $sm = [int]$job.smooth; $a = "-hide_banner -loglevel error -y -nostdin -ss $ss -t $tt -i `"$($job.src)`" -map 0:v:0 -map 0:a? -vf vidstabtransform=input=$($job.trf):smoothing=${sm}:optzoom=1:zoomspeed=0.2:interpol=bicubic,unsharp=5:5:0.5,format=yuv420p -c:v libx264 -preset veryfast -crf 17 -force_key_frames expr:gte(t,n_forced*1) -sc_threshold 0 -c:a aac -b:a 192k -movflags +faststart -progress `"$($job.prog)`" `"$($job.out)`"" }
  $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true; $psi.WorkingDirectory = $tmp
  $job.proc = [Diagnostics.Process]::Start($psi); $job.errTask = $job.proc.StandardError.ReadToEndAsync()
}
function Prog-Sec($file) { try { $t = Get-Content $file -Tail 12 -ErrorAction Stop | Where-Object { $_ -like 'out_time_us=*' } | Select-Object -Last 1; if ($t) { return ([double]($t -replace 'out_time_us=', '')) / 1e6 } } catch {}; return 0 }
function Job-Status($job) {
  if ($job.proxy) {
    if ($job.state -eq 'running') {
      if (-not $job.proc) {   # 차례를 기다리는 중: 다른 사본을 만들고 있지 않으면 시작
        $busy = @($jobs.Values | Where-Object { $_.proxy -and $_.proc -and -not $_.proc.HasExited }).Count
        if ($busy -eq 0) { Start-Proxy $job }
      } else {
        try {
          $t = Get-Content $job.prog -Tail 12 -ErrorAction Stop | Where-Object { $_ -like 'out_time_us=*' } | Select-Object -Last 1
          if ($t -and $job.dur -gt 0) { $job.pct = [math]::Min(99, [math]::Max(0, ([double]($t -replace 'out_time_us=', '')) / 1e6 / $job.dur * 100)) }
        } catch {}
        if ($job.proc.HasExited) {
          if ($job.proc.ExitCode -eq 0 -and (Test-Path -LiteralPath $job.out) -and (Get-Item -LiteralPath $job.out).Length -gt 1000) {
            $dest = Join-Path $proxyDir ($job.id + '.mp4'); Move-Item -LiteralPath $job.out $dest -Force; $job.final = $dest
            $cache[$job.key] = $dest; Save-Cache
            if ($job.inp) { Remove-Item -LiteralPath $job.inp -Force -ErrorAction SilentlyContinue }
            Remove-Item -LiteralPath $job.prog -Force -ErrorAction SilentlyContinue
            $job.state = 'done'; $job.pct = 100; Log "proxy done $($job.id) -> $dest"
          } elseif ($job.hw) { Log "proxy hw failed, retry: $($job.errTask.Result)"; $job.hw = $false; $job.proc = $null; Start-Proxy $job }
          elseif ($job.tm) { Log "proxy tonemap failed, retry: $($job.errTask.Result)"; $job.tm = $false; $job.proc = $null; Start-Proxy $job }
          else {
            $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "proxy error $($job.id): $($job.msg)"
            Remove-Item -LiteralPath $job.out, $job.prog -Force -ErrorAction SilentlyContinue; if ($job.inp) { Remove-Item -LiteralPath $job.inp -Force -ErrorAction SilentlyContinue }
          }
        }
      }
    }
    return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name; wait = [bool]($job.state -eq 'running' -and -not $job.proc) }
  }
  if ($job.stabJob) {
    if ($job.state -eq 'running') {
      $job.pct = $(if ($job.stage -eq 1) { [math]::Min(45, 45 * (Prog-Sec $job.prog1) / $job.len) } else { [math]::Min(99, 45 + 54 * (Prog-Sec $job.prog) / $job.len) })
      if ($job.proc.HasExited) {
        if ($job.proc.ExitCode -ne 0) { $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "stab error: $($job.msg)" }
        elseif ($job.stage -eq 1) { $job.stage = 2; Start-Stab $job }
        else { $job.state = 'done'; $job.pct = 100; Remove-Item (Join-Path $tmp $job.trf) -Force -ErrorAction SilentlyContinue; Log "stab done $($job.out)" }
      }
    }
    return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name; size = $(if ($job.state -eq 'done' -and (Test-Path $job.out)) { (Get-Item $job.out).Length } else { 0 }) }
  }
  if ($job.rev) {
    if ($job.state -eq 'running' -and $job.proc.HasExited) {
      if ($job.proc.ExitCode -ne 0) { $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "reverse error: $($job.msg)" }
      elseif ($job.concat) { $job.state = 'done'; $job.pct = 100; foreach ($p in $job.parts) { Remove-Item $p -Force -ErrorAction SilentlyContinue }; Log "reverse done $($job.out)" }
      else { $job.k++; $job.pct = [math]::Min(97, 97 * $job.k / $job.n); Start-Rev $job }
    }
    return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name; size = $(if ($job.state -eq 'done' -and (Test-Path $job.out)) { (Get-Item $job.out).Length } else { 0 }) }
  }
  if ($job.hyper -and $job.state -eq 'running') {
    $w1 = $(if ($job.stab) { 0.35 } else { 0 })
    if ($job.stage -eq 1) { $job.pct = [math]::Min(99, $w1 * 100 * (Prog-Sec $job.prog1) / $job.len) }
    else { $job.pct = [math]::Min(99, $w1 * 100 + (1 - $w1) * 100 * (Prog-Sec $job.prog) / $job.dur) }
    if ($job.proc.HasExited) {
      if ($job.stage -eq 1) {
        if ($job.proc.ExitCode -ne 0) { Log "vidstab failed, skip: $($job.errTask.Result)"; $job.stab = $false }
        $job.stage = 2; Start-Hyper $job
      } elseif ($job.proc.ExitCode -eq 0 -and (Test-Path $job.out)) { $job.state = 'done'; $job.pct = 100; Log "hyperlapse done $($job.out)"; if ($job.own) { Remove-Item $job.src -Force -ErrorAction SilentlyContinue } }
      else { $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "hyperlapse error: $($job.msg)" }
    }
    return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name }
  }
  if ($job.hyper) { return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name; size = $(if ($job.state -eq 'done' -and (Test-Path $job.out)) { (Get-Item $job.out).Length } else { 0 }) } }
  if ($job.state -eq 'running') {
    $pct = 0
    try {
      $t = Get-Content $job.prog -Tail 12 -ErrorAction Stop | Where-Object { $_ -like 'out_time_us=*' } | Select-Object -Last 1
      if ($t -and $job.dur -gt 0) { $pct = [math]::Min(99, [math]::Max(0, ([double]($t -replace 'out_time_us=', '')) / 1e6 / $job.dur * 100)) }
    } catch {}
    $job.pct = $pct
    if ($job.proc.HasExited -and $job.shrink) {
      if ($job.proc.ExitCode -eq 0 -and (Test-Path $job.out)) { $job.state = 'done'; $job.pct = 100; Log "shrink done $($job.out)" }
      else { $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "shrink error: $($job.msg)" }
    }
    elseif ($job.proc.HasExited) {
      if ($job.proc.ExitCode -eq 0 -and (Test-Path $job.out)) {
        # 다음에 같은 영상을 넣으면 바로 쓰도록 「변환된_영상」 폴더에 보관
        $dest = Join-Path $outDir ($job.base + '_편집용.mp4'); $k = 2
        while (Test-Path $dest) { $dest = Join-Path $outDir ("{0}_편집용({1}).mp4" -f $job.base, $k); $k++ }
        Move-Item $job.out $dest -Force; $job.final = $dest
        $cache[$job.key] = $dest; Save-Cache
        $job.state = 'done'; $job.pct = 100; Log "done $($job.id) -> $dest"
        Remove-Item $job.inp -Force -ErrorAction SilentlyContinue
      } elseif ($job.tonemap) {
        Log "tonemap failed: $($job.errTask.Result)"; Start-Ffmpeg $job $false
      } else {
        $job.state = 'error'; $job.msg = ($job.errTask.Result | Out-String).Trim(); Log "error $($job.id): $($job.msg)"
        Remove-Item $job.inp, $job.out -Force -ErrorAction SilentlyContinue
      }
    }
  }
  return @{state = $job.state; pct = [math]::Round($job.pct, 1); msg = $job.msg; name = $job.name; path = $(if ($job.shrink -and $job.state -eq 'done') { $job.out } else { $null }); size = $(if ($job.shrink -and $job.state -eq 'done') { (Get-Item $job.out).Length } else { 0 }) }
}

while ($L.IsListening) {
  $task = $L.GetContextAsync()
  while (-not $task.Wait(1000)) {
    Prune-Streams
    foreach ($j in @($jobs.Values)) { if ($j.state -eq 'running') { Job-Status $j | Out-Null } }
    if ((Get-Date) -gt $nextUpd){ $nextUpd = (Get-Date).AddMinutes(30); try { Start-UpdCheck } catch { Log "update check error: $_" } }   # 🔄 켠 뒤 20초, 그 뒤 30분마다
    $busy = @($jobs.Values | Where-Object { $_.state -eq 'running' }).Count
    if (-not $busy -and ((Get-Date) - $lastPing).TotalSeconds -gt 75 -and ((Get-Date) - $started).TotalSeconds -gt 60) { Log 'idle exit'; $L.Stop(); exit 0 }
  }
  $ctx = $task.Result; $req = $ctx.Request; $path = $req.Url.AbsolutePath
  # 🔒 보안: 이 컴퓨터의 편집기 창에서 온 요청만 받음 (다른 웹사이트가 몰래 부르거나, 주소를 속이는 공격 차단)
  $hostH = [string]$req.Headers['Host']; $orig = [string]$req.Headers['Origin']; $sfs = [string]$req.Headers['Sec-Fetch-Site']
  $okHost = ($hostH -eq "127.0.0.1:$Port") -or ($hostH -eq "localhost:$Port")
  $okOrig = (-not $orig) -or ($orig -eq "http://127.0.0.1:$Port") -or ($orig -eq "http://localhost:$Port")
  if (-not $okHost -or -not $okOrig -or ($sfs -eq 'cross-site' -and $path -ne '/ping')) {
    Log "blocked $path host=$hostH origin=$orig site=$sfs"; try { Send $ctx 403 'text/plain' 'forbidden' } catch {}; continue
  }
  # 주소 뒤의 값들을 UTF-8로 직접 풀어 읽음 (한글 파일 이름·경로가 깨지지 않도록)
  $q = @{}; $raw = $req.RawUrl; $qi = $raw.IndexOf('?')
  if ($qi -ge 0) { foreach ($pair in $raw.Substring($qi + 1).Split('&')) { if (-not $pair) { continue }; $kv = $pair.Split('=', 2); $q[[Uri]::UnescapeDataString($kv[0])] = $(if ($kv.Count -gt 1) { [Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) } else { '' }) } }
  try {
    # 🔒 비밀번호가 정해져 있으면: 맞는 비밀번호로 연 창(세션)만 통과. 아니면 잠금 화면만 보여 줌
    if ($path -eq '/unlock') {
      $lastPing = Get-Date
      if (-not $pwInfo) { Json $ctx @{ok = $true }; continue }
      if ((Get-Date) -lt $waitUntil) { Json $ctx @{ok = $false; wait = [int](($waitUntil - (Get-Date)).TotalSeconds) + 1 }; continue }
      $b = $null; try { $b = (ReadBody $req) | ConvertFrom-Json } catch {}
      $d = $null; if ($b) { $d = Check-Pw ([string]$b.pw) }
      if ($d) {
        $fails = 0; $keys = $d; $sid = ([Convert]::ToBase64String((New-Rand 24))) -replace '[+/=]', ''; $sessions.Add($sid) | Out-Null
        $ctx.Response.Headers.Add('Set-Cookie', "vpes=$sid; Path=/; HttpOnly; SameSite=Strict"); Log 'unlock ok'; Json $ctx @{ok = $true }; continue
      }
      $fails++; Log "unlock fail $fails"
      if ($fails -ge 5) { $sec = [math]::Min(600, 30 * [math]::Pow(2, $fails - 5)); $waitUntil = (Get-Date).AddSeconds($sec); Json $ctx @{ok = $false; wait = [int]$sec }; continue }
      Json $ctx @{ok = $false }; continue
    }
    if ($path -eq '/hint') { Json $ctx @{hint = $(if ($pwInfo) { [string]$pwInfo.hint } else { '' }) }; continue }
    if ($pwInfo -and $path -ne '/ping' -and -not (Has-Session $req)) {
      if ($path -eq '/' -or $path -eq '/index.html') { $lastPing = Get-Date; Send $ctx 200 'text/html; charset=utf-8' $lockPage; continue }
      Send $ctx 401 'text/plain' 'locked'; continue
    }
    if ($path -eq '/' -or $path -eq '/index.html') {
      $lastPing = Get-Date
      $page = [IO.File]::ReadAllText($html, [Text.Encoding]::UTF8)
      $rem = [string]$req.Headers['X-VPE-Remote']; $remSafe = $rem -replace '[^0-9.]', ''
      $helperObj = @{token = $token; ffmpeg = [bool]$ff; voice = [bool](Voice-Ready); pw = [bool]$pwInfo; autolock = $(if ($pwInfo) { [int]$pwInfo.autolock } else { 0 }); remote = [bool]$rem; saveName = $(if ($rem) { "원격_${remSafe}_최근.vpe.json" } else { '자동저장_최근.vpe.json' }) } | ConvertTo-Json -Compress
      $page = $page.Replace('/*@@HELPER@@*/null', $helperObj)
      Send $ctx 200 'text/html; charset=utf-8' $page; continue
    }
    if ($path -eq '/ping') { $lastPing = Get-Date; Send $ctx 200 'text/plain' $HelperVersion; continue }
    if ($path -eq '/manual') {   # 📘 사용설명서 (프로그램 폴더의 정해진 파일 하나만)
      $mf = Join-Path $root '사용설명서.html'; if (Test-Path -LiteralPath $mf) { Send $ctx 200 'text/html; charset=utf-8' ([IO.File]::ReadAllBytes($mf)) } else { Send $ctx 404 'text/plain; charset=utf-8' '사용설명서.html이 없어요' }; continue }
    if ($req.Headers['X-VPE-Token'] -ne $token -and $q['t'] -ne $token) { Send $ctx 403 'text/plain' 'forbidden'; continue }
    $lastPing = Get-Date
    switch ($path) {
      '/api/cached' {
        $key = "$($q['name'])|$($q['size'])"
        if ($cache.ContainsKey($key) -and (Test-Path $cache[$key])) {
          $id = [guid]::NewGuid().ToString('N'); $jobs[$id] = @{id = $id; state = 'done'; pct = 100; final = $cache[$key]; name = $q['name'] }
          Json $ctx @{cached = $true; id = $id }
        } else { Json $ctx @{cached = $false } }
      }
      '/api/proxy' {
        # 🎞 미리보기용 가벼운 사본 만들기 (이미 있으면 바로) · 원본은 이름·크기로 찾고, 못 찾으면 편집기가 파일을 보내 줌(POST)
        if (-not $ff -or -not $fp) { Json $ctx @{skip = $true; why = 'noffmpeg' }; break }
        $pnm = [string]$q['name']; $pwant = 0; [void][int64]::TryParse([string]$q['size'], [ref]$pwant)
        $plong = 1280; [void][int]::TryParse([string]$q['long'], [ref]$plong); $plong = [math]::Max(640, [math]::Min(1920, $plong))
        $pkey = "proxy$plong|$pnm|$pwant"
        if ($cache.ContainsKey($pkey) -and (Test-Path -LiteralPath $cache[$pkey])) {
          $pid2 = [guid]::NewGuid().ToString('N'); $jobs[$pid2] = @{id = $pid2; state = 'done'; pct = 100; final = $cache[$pkey]; name = $pnm; proxy = $true }
          try { (Get-Item -LiteralPath $cache[$pkey]).LastWriteTime = Get-Date } catch {}   # 쓴 날을 기록 (30일 안 쓰면 지움)
          Json $ctx @{id = $pid2; cached = $true }; break
        }
        $prun = @($jobs.Values | Where-Object { $_.proxy -and $_.key -eq $pkey -and $_.state -eq 'running' }) | Select-Object -First 1
        if ($prun) { Json $ctx @{id = $prun.id }; break }
        $psrc = $null; $pjj = $jobs[[string]$q['id']]; if ($pjj -and $pjj.final -and (Test-Path -LiteralPath $pjj.final)) { $psrc = $pjj.final }
        if (-not $psrc -and $pnm) { $pf = Find-Media $pnm $pwant -Quick; if ($pf) { $psrc = $pf.FullName } }
        $pid2 = [guid]::NewGuid().ToString('N'); $pinp = $null
        if (-not $psrc -and $req.HttpMethod -eq 'POST' -and $req.HasEntityBody) { $pinp = Join-Path $tmp "$pid2.pin"; $pfs = [IO.File]::Create($pinp); try { $req.InputStream.CopyTo($pfs, 4MB) } finally { $pfs.Close() }; $psrc = $pinp }
        if (-not $psrc) { Json $ctx @{need = 'upload' }; break }
        $pinfo = Probe $psrc
        $pw = 0; $ph = 0; [void][int]::TryParse([string]$pinfo['width'], [ref]$pw); [void][int]::TryParse([string]$pinfo['height'], [ref]$ph)
        if (-not $pinfo['codec_name'] -or $pw -le 0 -or $ph -le 0) { if ($pinp) { Remove-Item -LiteralPath $pinp -Force -ErrorAction SilentlyContinue }; Json $ctx @{skip = $true; why = 'notvideo' }; break }
        $pfr = & $fp -v error -select_streams v:0 -show_entries stream=avg_frame_rate,r_frame_rate,pix_fmt -of default=nw=1 "$psrc" 2>$null
        $pfps = 0.0; $ppix = ''
        foreach ($pline in $pfr) { $k1, $v1 = ([string]$pline) -split '=', 2;   <# ⚠ $l 을 쓰면 서버 변수 $L 을 덮어써서 도우미가 꺼짐 (대소문자 구분 안 함) #> if ($k1 -eq 'pix_fmt') { $ppix = $v1 } elseif ($pfps -le 0 -and $v1 -match '^(\d+)/(\d+)$' -and [double]$matches[2] -gt 0) { $pv = [double]$matches[1] / [double]$matches[2]; if ($pv -gt 1 -and $pv -lt 241) { $pfps = $pv } } }
        $pheavy = ([math]::Max($pw, $ph) -gt $plong + 8) -or ($pfps -gt 31) -or ($ppix -match '1[02]') -or ($pinfo['codec_name'] -ne 'h264')
        if (-not $pheavy) { if ($pinp) { Remove-Item -LiteralPath $pinp -Force -ErrorAction SilentlyContinue }; Json $ctx @{skip = $true; why = 'light' }; break }
        $pk = [math]::Min(1.0, $plong / [double][math]::Max($pw, $ph)); $ptw = [int]([math]::Round($pw * $pk / 2) * 2); $pth = [int]([math]::Round($ph * $pk / 2) * 2)
        $pdur = 0.0; [double]::TryParse([string]$pinfo['duration'], [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$pdur) | Out-Null
        $phdr = ($pinfo['color_transfer'] -eq 'arib-std-b67' -or $pinfo['color_transfer'] -eq 'smpte2084')
        $pjob = @{id = $pid2; proxy = $true; key = $pkey; name = $pnm; src = $psrc; inp = $pinp; out = (Join-Path $proxyDir "$pid2.part.mp4"); prog = (Join-Path $tmp "$pid2.pprog"); dur = $pdur; tw = $ptw; th = $pth; fps30 = ($pfps -gt 31); tm = $phdr; hw = $true; state = 'running'; pct = 0; msg = '' }
        $jobs[$pid2] = $pjob; Job-Status $pjob | Out-Null
        Json $ctx @{id = $pid2; w = $ptw; h = $pth; fps = $pfps }
      }
      '/api/convert' {
        if (-not $ff) { Json $ctx @{error = 'noffmpeg' }; break }
        $id = [guid]::NewGuid().ToString('N')
        $name = [string]$q['name']; $base = [IO.Path]::GetFileNameWithoutExtension($name) -replace '[\\/:*?"<>|]', '_'
        $inp = Join-Path $tmp "$id.in"; $fs = [IO.File]::Create($inp)
        try { $req.InputStream.CopyTo($fs, 4MB) } finally { $fs.Close() }
        $info = Probe $inp
        $dur = 0.0; [double]::TryParse([string]$info['duration'], [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$dur) | Out-Null
        if (-not $info['codec_name']) { Remove-Item $inp -Force; Json $ctx @{error = 'notvideo' }; break }
        $job = @{id = $id; name = $name; base = $base; key = "$name|$($q['size'])"; inp = $inp; out = (Join-Path $tmp "$id.out.mp4"); prog = (Join-Path $tmp "$id.prog"); dur = $dur; w = $info['width']; h = $info['height']; state = 'running'; pct = 0; msg = '' }
        $jobs[$id] = $job
        $hdr = ($info['color_transfer'] -eq 'arib-std-b67' -or $info['color_transfer'] -eq 'smpte2084')
        Start-Ffmpeg $job $hdr
        Json $ctx @{id = $id; codec = $info['codec_name']; hdr = $hdr; duration = $dur; width = $info['width']; height = $info['height'] }
      }
      '/api/status' { $j = $jobs[$q['id']]; if ($j) { Json $ctx (Job-Status $j) } else { Json $ctx @{state = 'error'; msg = 'nojob' } } }
      '/api/cancel' {
        $j = $jobs[$q['id']]
        if ($j -and $j.proc -and -not $j.proc.HasExited) { $j.proc.Kill(); $j.proc.WaitForExit(3000) | Out-Null }
        if ($j) { $j.state = 'cancelled'; $del = @($j.inp, $j.out, $j.prog, $j.prog1) | Where-Object { $_ }; if ($del) { Remove-Item -LiteralPath $del -Force -ErrorAction SilentlyContinue } }   # 하이퍼랩스 등 입력 파일이 없는 작업도 오류 없이 취소
        Json $ctx @{ok = $true }
      }
      '/api/out' {
        $j = $jobs[$q['id']]
        if (-not $j -or $j.state -ne 'done') { Send $ctx 404 'text/plain' 'not ready'; break }
        $res = $ctx.Response; $res.ContentType = 'video/mp4'; $f = [IO.File]::OpenRead($j.final)
        try { $res.ContentLength64 = $f.Length; $f.CopyTo($res.OutputStream, 4MB) } finally { $f.Close(); $res.OutputStream.Close() }
      }
      # ===== 완성된 영상 저장 · 보내기 =====
      '/api/save/begin' {
        $name = ([string]$q['name']) -replace '[\\/:*?"<>|]', '_'; if (-not $name) { $name = '내영상.mp4' }
        $dest = Join-Path $doneDir $name; $base = [IO.Path]::GetFileNameWithoutExtension($name); $ext = [IO.Path]::GetExtension($name); $k = 2
        while (Test-Path $dest) { $dest = Join-Path $doneDir ("{0}({1}){2}" -f $base, $k, $ext); $k++ }
        $sid = [guid]::NewGuid().ToString('N'); $saves[$sid] = @{path = $dest; fs = [IO.File]::Create($dest) }
        Json $ctx @{id = $sid; path = $dest; name = [IO.Path]::GetFileName($dest) }
      }
      '/api/save/chunk' {
        $sv = $saves[$q['id']]; if (-not $sv) { Send $ctx 404 'text/plain' 'nosave'; break }
        $req.InputStream.CopyTo($sv.fs, 1MB); Json $ctx @{ok = $true; size = $sv.fs.Length }
      }
      '/api/save/end' {
        $sv = $saves[$q['id']]; if (-not $sv) { Send $ctx 404 'text/plain' 'nosave'; break }
        $sv.fs.Close(); $saves.Remove($q['id'])
        if ($q['abort'] -eq '1') { Remove-Item $sv.path -Force -ErrorAction SilentlyContinue; Json $ctx @{ok = $true; aborted = $true } }
        else { Log "saved $($sv.path)"; Cloud-Done $sv.path; Json $ctx @{ok = $true; path = $sv.path; size = (Get-Item $sv.path).Length } }
      }
      # 🎞 고화질 저장: 편집기가 장면 하나하나 압축한 영상(H.264) + 미리 섞은 소리(WAV) → ffmpeg가 MP4로 묶음
      '/api/vinfo' {
        # 영상의 초당 장면 수 (고화질 저장에서 같은 장면을 다시 찾지 않으려고)
        $p = $null; $jj = $jobs[[string]$q['id']]; if ($jj -and $jj.final -and (Test-Path -LiteralPath $jj.final)) { $p = $jj.final }
        if (-not $p -and $q['name']) { $want = 0; [void][int64]::TryParse([string]$q['size'], [ref]$want); $f = Find-Media ([string]$q['name']) $want -Quick; if ($f) { $p = $f.FullName } }
        if (-not $p -or -not $fp) { Json $ctx @{ok = $false }; break }
        $fr = & $fp -v error -select_streams v:0 -show_entries stream=avg_frame_rate,r_frame_rate -of csv=p=0 "$p" 2>$null | Select-Object -First 1
        $fps = 0.0; foreach ($x in ([string]$fr -split ',')) { if ($x -match '^(\d+)/(\d+)$' -and [double]$matches[2] -gt 0) { $v = [double]$matches[1] / [double]$matches[2]; if ($v -gt 1 -and $v -lt 241) { $fps = $v; break } } }
        Json $ctx @{ok = ($fps -gt 0); fps = $fps }
      }
      '/api/hq/frames' {
        $p = $null; $jj = $jobs[[string]$q['id']]; if ($jj -and $jj.final -and (Test-Path -LiteralPath $jj.final)) { $p = $jj.final }
        if (-not $p -and $q['name']) { $want = 0; [void][int64]::TryParse([string]$q['size'], [ref]$want); $f = Find-Media ([string]$q['name']) $want -Quick; if ($f) { $p = $f.FullName } }
        if (-not $p -or -not $ff) { Send $ctx 404 'text/plain' 'nofile'; break }
        $inv = [Globalization.CultureInfo]::InvariantCulture; $ss = [double]::Parse([string]$q['ss'], $inv).ToString('0.####', $inv); $du = [double]::Parse([string]$q['dur'], $inv).ToString('0.####', $inv)
        Frames-Async $ctx $p $ss $du ([int]$q['w']) ([int]$q['h'])
      }
      '/api/hq/begin' {
        $hid = [guid]::NewGuid().ToString('N'); $vp = Join-Path $tmp "$hid.h264"; $ap = Join-Path $tmp "$hid.wav"
        $saves["hq_$hid"] = @{v = $vp; a = $ap; fs = [IO.File]::Create($vp) }
        Json $ctx @{id = $hid }
      }
      '/api/hq/v' {
        $sv = $saves["hq_$($q['id'])"]; if (-not $sv) { Send $ctx 404 'text/plain' 'nohq'; break }
        $req.InputStream.CopyTo($sv.fs, 1MB); Json $ctx @{ok = $true; size = $sv.fs.Length }
      }
      '/api/hq/a' {
        $sv = $saves["hq_$($q['id'])"]; if (-not $sv) { Send $ctx 404 'text/plain' 'nohq'; break }
        $afs = [IO.File]::Create($sv.a); try { $req.InputStream.CopyTo($afs, 1MB) } finally { $afs.Close() }; Json $ctx @{ok = $true }
      }
      '/api/hq/end' {
        $key = "hq_$($q['id'])"; $sv = $saves[$key]; if (-not $sv) { Send $ctx 404 'text/plain' 'nohq'; break }
        $sv.fs.Close(); $saves.Remove($key)
        if ($q['abort'] -eq '1' -or -not $ff) { Remove-Item $sv.v, $sv.a -Force -ErrorAction SilentlyContinue; Json $ctx @{ok = $false; aborted = $true }; break }
        $name = ([string]$q['name']) -replace '[\\/:*?"<>|]', '_'; if (-not $name) { $name = '내영상.mp4' }
        $dest = Join-Path $doneDir $name; $base = [IO.Path]::GetFileNameWithoutExtension($name); $k = 2
        while (Test-Path $dest) { $dest = Join-Path $doneDir ("{0}({1}).mp4" -f $base, $k); $k++ }
        $fps = [string]$q['fps']; if ($fps -notmatch '^\d+(\.\d+)?$') { $fps = '30' }
        $aIn = if ((Test-Path $sv.a) -and (Get-Item $sv.a).Length -gt 100) { "-i `"$($sv.a)`" -map 0:v:0 -map 1:a:0 $(if ($q['norm'] -eq '1') { '-af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000' }) -c:a aac -b:a 256k" } else { "-map 0:v:0" }
        $a = "-hide_banner -loglevel error -y -nostdin -fflags +genpts -r $fps -f h264 -i `"$($sv.v)`" $aIn -c:v copy -movflags +faststart `"$dest`""
        $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
        $p = [Diagnostics.Process]::Start($psi); $err = $p.StandardError.ReadToEnd(); $p.WaitForExit()
        if ($p.ExitCode -ne 0 -and $a -match 'loudnorm') {   # 아주 짧거나 조용한 소리는 크기 맞추기가 실패할 수 있어 → 맞추지 않고 다시
          Log "loudnorm failed, retry without"; $a = $a -replace '-af loudnorm=\S+ -ar 48000 ', ''; $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
          $p = [Diagnostics.Process]::Start($psi); $err = $p.StandardError.ReadToEnd(); $p.WaitForExit() }
        Remove-Item $sv.v, $sv.a -Force -ErrorAction SilentlyContinue
        if ($p.ExitCode -ne 0 -or -not (Test-Path $dest)) { Log "hq mux error: $err"; Json $ctx @{ok = $false; error = $err.Trim() }; break }
        Log "hq saved $dest"; Cloud-Done $dest; Json $ctx @{ok = $true; path = $dest; name = [IO.Path]::GetFileName($dest); size = (Get-Item $dest).Length }
      }
      '/api/vfx/end' {
        # 🏃 움직이는 것 지우기 등: 편집기가 새로 만든 장면(H.264) + 원본 영상의 같은 구간 소리 → 「변환된_영상」에 MP4로
        $key = "hq_$($q['id'])"; $sv = $saves[$key]; if (-not $sv) { Send $ctx 404 'text/plain' 'nohq'; break }
        $sv.fs.Close(); $saves.Remove($key)
        if ($q['abort'] -eq '1' -or -not $ff) { Remove-Item $sv.v, $sv.a -Force -ErrorAction SilentlyContinue; Json $ctx @{ ok = $false; aborted = $true }; break }
        $src = $null; $jj = $jobs[[string]$q['src']]; if ($jj -and $jj.final -and (Test-Path -LiteralPath $jj.final)) { $src = $jj.final }
        if (-not $src -and $q['name']) { $want = 0; [void][int64]::TryParse([string]$q['size'], [ref]$want); $f = Find-Media ([string]$q['name']) $want -Quick; if ($f) { $src = $f.FullName } }
        $inv = [Globalization.CultureInfo]::InvariantCulture; $ss = [double]::Parse([string]$q['ss'], $inv).ToString('0.####', $inv); $du = [double]::Parse([string]$q['dur'], $inv).ToString('0.####', $inv)
        $fps = [string]$q['fps']; if ($fps -notmatch '^\d+(\.\d+)?$') { $fps = '30' }
        $base = ([IO.Path]::GetFileNameWithoutExtension([string]$q['base'])) -replace '[\\/:*?"<>|]', '_'; if (-not $base) { $base = '영상' }
        $out = Join-Path $outDir ("{0}_지움.mp4" -f $base); $k = 2; while (Test-Path -LiteralPath $out) { $out = Join-Path $outDir ("{0}_지움({1}).mp4" -f $base, $k); $k++ }
        $aIn = $(if ($src) { "-ss $ss -t $du -i `"$src`" -map 0:v:0 -map 1:a:0? -c:a aac -b:a 192k" } else { '-map 0:v:0' })
        $a = "-hide_banner -loglevel error -y -nostdin -fflags +genpts -r $fps -f h264 -i `"$($sv.v)`" $aIn -c:v copy -movflags +faststart `"$out`""
        $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
        $p = [Diagnostics.Process]::Start($psi); $err = $p.StandardError.ReadToEnd(); $p.WaitForExit()
        Remove-Item $sv.v, $sv.a -Force -ErrorAction SilentlyContinue
        if ($p.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $out)) { Log "vfx mux error: $err"; Json $ctx @{ ok = $false; error = $err.Trim() }; break }
        $id = [guid]::NewGuid().ToString('N'); $jobs[$id] = @{ id = $id; state = 'done'; pct = 100; final = $out; name = [IO.Path]::GetFileName($out) }
        Log "vfx saved $out"; Json $ctx @{ ok = $true; id = $id; name = [IO.Path]::GetFileName($out); size = (Get-Item -LiteralPath $out).Length }
      }
      '/api/reveal' {
        $p = Safe-Path $q['path']; if (-not $p) { Json $ctx @{ok = $false }; break }
        if ($q['dry'] -ne '1') { Start-Process explorer.exe "/select,`"$p`"" }
        Json $ctx @{ok = $true }
      }
      '/api/clipfile' {
        # 영상 파일을 「복사」해 둠 → 카톡 대화방에서 Ctrl+V 로 붙여 보냄 (끌어다 놓기가 막힐 때도 됨)
        $p = Safe-Path $q['path']; if (-not $p) { Json $ctx @{ok = $false }; break }
        if ($q['dry'] -ne '1') {
          $lit = $p.Replace("'", "''")
          $psi = New-Object Diagnostics.ProcessStartInfo 'powershell.exe', ("-NoProfile -STA -WindowStyle Hidden -Command `"Set-Clipboard -LiteralPath '" + $lit + "'`"")
          $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
          $cp = [Diagnostics.Process]::Start($psi); [void]$cp.WaitForExit(8000)
          Json $ctx @{ok = ($cp.HasExited -and $cp.ExitCode -eq 0) }
        } else { Json $ctx @{ok = $true } }
      }
      '/api/kakao' {
        $kk = @("${env:ProgramFiles(x86)}\Kakao\KakaoTalk\KakaoTalk.exe", "$env:ProgramFiles\Kakao\KakaoTalk\KakaoTalk.exe", "$env:LOCALAPPDATA\Kakao\KakaoTalk\KakaoTalk.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
        if ($kk -and $q['dry'] -ne '1') { Start-Process $kk }
        Json $ctx @{found = [bool]$kk }
      }
      '/api/mail' {
        $p = Safe-Path $q['path']; if (-not $p) { Json $ctx @{ok = $false }; break }
        $ol = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\OUTLOOK.EXE' -ErrorAction SilentlyContinue).'(default)'
        if ($ol -and (Test-Path $ol)) { if ($q['dry'] -ne '1') { Start-Process $ol -ArgumentList '/a', "`"$p`"" }; Json $ctx @{ok = $true; via = 'outlook' } }
        else { Json $ctx @{ok = $false; via = 'none' } }
      }
      '/api/shrink' {
        # 보내기용으로 작게: 목표 용량(MB)에 맞춰 화질을 낮춤 (720p)
        $p = Safe-Path $q['path']; if (-not $p -or -not $ff) { Json $ctx @{error = 'bad' }; break }
        $mb = [double]$q['mb']; if ($mb -le 0) { $mb = 25 }
        $info = Probe $p; $dur = 0.0; [double]::TryParse([string]$info['duration'], [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$dur) | Out-Null; if ($dur -le 0) { $dur = 60 }
        $kbps = [math]::Max(300, [math]::Floor(($mb * 8192 * 0.92) / $dur) - 128)
        $id = [guid]::NewGuid().ToString('N'); $base = [IO.Path]::GetFileNameWithoutExtension($p)
        $out = Join-Path $doneDir ("{0}_보내기용_{1}MB.mp4" -f $base, [int]$mb); $k = 2; while (Test-Path $out) { $out = Join-Path $doneDir ("{0}_보내기용_{1}MB({2}).mp4" -f $base, [int]$mb, $k); $k++ }
        $job = @{id = $id; name = [IO.Path]::GetFileName($out); state = 'running'; pct = 0; msg = ''; dur = $dur; prog = (Join-Path $tmp "$id.prog"); out = $out; final = $out; shrink = $true }
        $a = "-hide_banner -loglevel error -y -nostdin -i `"$p`" -vf scale='min(1280,iw)':-2 -c:v libx264 -preset veryfast -force_key_frames expr:gte(t,n_forced*1) -sc_threshold 0 -b:v ${kbps}k -maxrate $([int]($kbps*1.3))k -bufsize $([int]($kbps*2))k -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart -progress `"$($job.prog)`" `"$out`""
        $psi = New-Object Diagnostics.ProcessStartInfo $ff, $a; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardError = $true
        $job.proc = [Diagnostics.Process]::Start($psi); $job.errTask = $job.proc.StandardError.ReadToEndAsync()
        $jobs[$id] = $job; Log "shrink $p -> $out (${kbps}kbps)"
        Json $ctx @{id = $id; kbps = $kbps }
      }
      '/api/hyperlapse' {
        # 🚀 하이퍼랩스: 긴 영상을 짧게 (흔들림 줄이기 → 앞뒤 장면 섞기 → 빠르게)
        if (-not $ff) { Json $ctx @{error = 'noffmpeg' }; break }
        $id = [guid]::NewGuid().ToString('N')
        $src = $null
        if ($q['src']) { $sj = $jobs[$q['src']]; if ($sj -and $sj.final -and (Test-Path $sj.final)) { $src = $sj.final } }
        if (-not $src) { $src = Join-Path $tmp "$id.in"; $fs = [IO.File]::Create($src); try { $req.InputStream.CopyTo($fs, 4MB) } finally { $fs.Close() }; $own = $true } else { $own = $false }
        $inv = [Globalization.CultureInfo]::InvariantCulture
        $t0 = [double]::Parse([string]$q['in'], $inv); $t1 = [double]::Parse([string]$q['out'], $inv); $tg = [double]::Parse([string]$q['target'], $inv)
        $len = [math]::Max(0.5, $t1 - $t0); $F = [math]::Max(1.0, $len / $tg)
        # 원본 초당 장면 수(25·30·60 등)를 읽어서, 몇 장마다 1장을 쓸지(R)와 몇 장을 섞을지(K) 정함
        $fr = & $fp -v error -select_streams v:0 -show_entries stream=r_frame_rate -of csv=p=0 "$src" 2>$null; $Sfps = 30.0
        if ($fr -match '^(\d+)/(\d+)') { $Sfps = [double]$matches[1] / [math]::Max(1, [double]$matches[2]) }
        $winR = [int][math]::Max(1, [math]::Round($len * $Sfps / ($tg * 30)))
        $mixK = $(if ($q['blend'] -ne '0') { [int][math]::Min(8, [math]::Max(2, [math]::Round($winR / 3))) } else { 1 }); if ($mixK -gt $winR) { $mixK = $winR }
        $base = ([IO.Path]::GetFileNameWithoutExtension([string]$q['name'])) -replace '[\\/:*?"<>|]', '_'
        $out = Join-Path $outDir ("{0}_하이퍼랩스_{1}초.mp4" -f $base, [int]$tg); $k = 2; while (Test-Path $out) { $out = Join-Path $outDir ("{0}_하이퍼랩스_{1}초({2}).mp4" -f $base, [int]$tg, $k); $k++ }
        $job = @{id = $id; name = [IO.Path]::GetFileName($out); state = 'running'; pct = 0; msg = ''; hyper = $true; stage = 1; src = $src; own = $own; out = $out; final = $out
          t0 = $t0; len = $len; F = $F; K = $mixK; R = $winR; stab = ($q['stab'] -eq '1'); blend = ($q['blend'] -ne '0'); prog1 = (Join-Path $tmp "$id.p1"); prog = (Join-Path $tmp "$id.p2"); trf = "$id.trf"; dur = $tg }
        $jobs[$id] = $job; Start-Hyper $job
        Json $ctx @{id = $id; speed = [math]::Round($F, 1); blend = $mixK }
      }
      '/api/stab' {
        if (-not $ff) { Json $ctx @{error = 'noffmpeg' }; break }
        $id = [guid]::NewGuid().ToString('N'); $src = $null
        if ($q['src']) { $sj = $jobs[$q['src']]; if ($sj -and $sj.final -and (Test-Path $sj.final)) { $src = $sj.final } }
        if (-not $src) { $src = Join-Path $tmp "$id.in"; $fs = [IO.File]::Create($src); try { $req.InputStream.CopyTo($fs, 4MB) } finally { $fs.Close() } }
        $inv = [Globalization.CultureInfo]::InvariantCulture; $t0 = [double]::Parse([string]$q['in'], $inv); $t1 = [double]::Parse([string]$q['out'], $inv)
        $sm = 20; [void][int]::TryParse([string]$q['smooth'], [ref]$sm)
        $base = ([IO.Path]::GetFileNameWithoutExtension([string]$q['name'])) -replace '[\\/:*?"<>|]', '_'
        $out = Join-Path $outDir ("{0}_흔들림줄임.mp4" -f $base); $k = 2; while (Test-Path $out) { $out = Join-Path $outDir ("{0}_흔들림줄임({1}).mp4" -f $base, $k); $k++ }
        $job = @{id = $id; name = [IO.Path]::GetFileName($out); state = 'running'; pct = 0; msg = ''; stabJob = $true; stage = 1; src = $src; out = $out; final = $out; t0 = $t0; len = [math]::Max(0.3, $t1 - $t0); smooth = $sm; trf = "$id.trf"; prog1 = (Join-Path $tmp "$id.s1"); prog = (Join-Path $tmp "$id.s2") }
        $jobs[$id] = $job; Log "stab $base $t0~$t1 -> $out"; Start-Stab $job
        Json $ctx @{id = $id }
      }
      '/api/reverse' {
        if (-not $ff) { Json $ctx @{error = 'noffmpeg' }; break }
        $id = [guid]::NewGuid().ToString('N'); $src = $null
        if ($q['src']) { $sj = $jobs[$q['src']]; if ($sj -and $sj.final -and (Test-Path $sj.final)) { $src = $sj.final } }
        if (-not $src) { $src = Join-Path $tmp "$id.in"; $fs = [IO.File]::Create($src); try { $req.InputStream.CopyTo($fs, 4MB) } finally { $fs.Close() } }
        $inv = [Globalization.CultureInfo]::InvariantCulture
        $t0 = [double]::Parse([string]$q['in'], $inv); $t1 = [double]::Parse([string]$q['out'], $inv); $len = [math]::Max(0.3, $t1 - $t0)
        $base = ([IO.Path]::GetFileNameWithoutExtension([string]$q['name'])) -replace '[\\/:*?"<>|]', '_'
        $out = Join-Path $outDir ("{0}_거꾸로.mp4" -f $base); $k = 2; while (Test-Path $out) { $out = Join-Path $outDir ("{0}_거꾸로({1}).mp4" -f $base, $k); $k++ }
        $job = @{id = $id; name = [IO.Path]::GetFileName($out); state = 'running'; pct = 0; msg = ''; rev = $true; src = $src; out = $out; final = $out; t0 = $t0; len = $len; n = [int][math]::Ceiling($len / 2.0 - 0.001); k = 0; parts = @(); concat = $false }
        $jobs[$id] = $job; Log "reverse $base $t0~$t1 -> $out"; Start-Rev $job
        Json $ctx @{id = $id }
      }
      '/api/tele' {
        # 🛰 비행 기록: 원본 드론 영상을 이름(+크기)로 찾아서 읽음 (한 번 읽으면 「.비행기록」 폴더에 기억)
        if (-not $ff) { Json $ctx @{ ok = $false; error = 'noffmpeg' }; break }
        $nm = [string]$q['name']; $want = 0; [void][int64]::TryParse([string]$q['size'], [ref]$want)
        if (-not (Test-Path $teleDir)) { New-Item -ItemType Directory -Force $teleDir | Out-Null; try { (Get-Item $teleDir).Attributes += 'Hidden' } catch {} }
        $cj = Join-Path $teleDir (($nm -replace '[\\/:*?"<>|]', '_') + '.json')
        if (Test-Path -LiteralPath $cj) { $b = [IO.File]::ReadAllBytes($cj); $res = $ctx.Response; $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $b.Length; $res.OutputStream.Write($b, 0, $b.Length); $res.OutputStream.Close(); break }
        $f = Find-Media $nm $want; if (-not $f -and $want -gt 0) { $f = Find-Media $nm 0 }
        if (-not $f) { Json $ctx @{ ok = $false; error = 'nofile' }; break }
        Log "tele $($f.FullName)"; Tele-Async $ctx $f.FullName $cj
      }
      '/api/local' {
        # 「변환된_영상」 폴더에 있는 파일(하이퍼랩스 등)을 이름으로 다시 열기 — 이어서 하기용
        $nm = ([IO.Path]::GetFileName([string]$q['name'])); $p = Join-Path $outDir $nm
        if ($nm -and (Test-Path -LiteralPath $p -PathType Leaf) -and (Get-Item -LiteralPath $p).Length -gt 0) { $id = [guid]::NewGuid().ToString('N'); $jobs[$id] = @{id = $id; state = 'done'; pct = 100; final = $p; name = $nm }; Json $ctx @{found = $true; id = $id; size = (Get-Item -LiteralPath $p).Length } }
        else { Json $ctx @{found = $false } }
      }
      '/api/savedfile' {
        $p = Safe-Path $q['path']; if (-not $p) { Send $ctx 404 'text/plain' 'no'; break }
        $res = $ctx.Response; $f = [IO.File]::OpenRead($p)
        try { $res.ContentType = 'video/mp4'; $res.ContentLength64 = $f.Length; $f.CopyTo($res.OutputStream, 1MB) } catch {} finally { $f.Close(); try { $res.OutputStream.Close() } catch {} }
      }
      # ===== 💾 작업 파일 저장 (브라우저 저장소가 지워져도 남도록 「작업저장」 폴더에도 보관) =====
      '/api/project/save' {
        $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd(); $sr.Close()
        if ($txt.Length -lt 20 -or $txt -notmatch '"clips"\s*:\s*\[\s*\{') { Json $ctx @{ok = $false; why = 'empty' }; break }   # 빈 작업은 절대 덮어쓰지 않음
        New-Item -ItemType Directory -Force $projDir | Out-Null
        $rem = ([string]$req.Headers['X-VPE-Remote']) -replace '[^0-9.]', ''; $pref = $(if ($rem) { "원격_${rem}_" } else { '자동저장_' })   # 📱 다른 기기에서 연결한 작업은 기기마다 따로
        $latest = Join-Path $projDir ($pref + '최근.vpe.json')
        Write-Proj $latest $txt   # 비밀번호가 있으면 암호화해서 저장
        # 5분마다 한 번씩은 따로 한 벌 더 보관 (최근 40개)
        $hist = Get-ChildItem $projDir -Filter ($pref + '20*.vpe.json') -ErrorAction SilentlyContinue | Sort-Object LastWriteTime
        $last = $hist | Select-Object -Last 1; $dated = $null
        if (-not $last -or ((Get-Date) - $last.LastWriteTime).TotalMinutes -ge 5 -or $q['force'] -eq '1') {
          $dated = Join-Path $projDir ($pref + ("{0:yyyy-MM-dd_HH시mm분ss초}.vpe.json" -f (Get-Date)))
          Copy-Item -LiteralPath $latest -Destination $dated -Force
          $hist = Get-ChildItem $projDir -Filter ($pref + '20*.vpe.json') | Sort-Object LastWriteTime
          if ($hist.Count -gt 40) { $hist | Select-Object -First ($hist.Count - 40) | Remove-Item -Force }
        }
        Cloud-Project $latest $dated   # ☁ 켜 두었으면 클라우드 폴더에도
        Json $ctx @{ok = $true }
      }
      '/api/project/reveal' {
        New-Item -ItemType Directory -Force $projDir | Out-Null; Start-Process explorer.exe "`"$projDir`""; Json $ctx @{ok = $true }
      }
      '/api/find' {
        # 이어서 하기 때 원본 파일을 이름으로 다시 찾기 (DJI Album·바탕화면·사진·동영상·다운로드 폴더, 두 단계 아래까지)
        $nm = [IO.Path]::GetFileName([string]$q['name']); $want = [int64]0; [int64]::TryParse([string]$q['size'], [ref]$want) | Out-Null
        $found = $null
        # 🔒 사진·영상·음악 파일만 찾음 (문서 등 다른 파일은 절대 열지 않음), 이름에 와일드카드(*,?) 금지
        if ($nm -notmatch $mediaExt -or $nm -match '[*?]') { $nm = $null }
        if ($nm) { $found = Find-Media $nm $want -Quick:($q['quick'] -eq '1') }
        if ($found) {
          $k = "$nm|$want"; if ($want -gt 0 -and $locs[$k] -ne $found.FullName) { $locs[$k] = $found.FullName; Save-Locs }   # 다음에는 바로 찾도록 기억
          if ($q['remember'] -eq '1') { Json $ctx @{found = $true; size = $found.Length }; break }       # 위치만 기억 (파일을 열지는 않음)
          $id = [guid]::NewGuid().ToString('N'); $jobs[$id] = @{id = $id; state = 'done'; pct = 100; final = $found.FullName; name = $found.Name }; Json $ctx @{found = $true; id = $id; size = $found.Length }
        }
        else { Json $ctx @{found = $false } }
      }
      '/api/project/list' {
        $items = @(Get-ChildItem $projDir -Filter '*.vpe.json' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 60 | ForEach-Object { @{name = $_.Name; time = [long](($_.LastWriteTimeUtc - [datetime]'1970-01-01').TotalMilliseconds); size = $_.Length } })
        Json $ctx @{items = $items }
      }
      '/api/project/load' {
        $nm = [IO.Path]::GetFileName([string]$q['name']); $p = Join-Path $projDir $nm
        if (-not $nm -or -not (Test-Path -LiteralPath $p -PathType Leaf)) { Send $ctx 404 'text/plain' 'no'; break }
        $plain = Dec-Text ([IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)) $keys
        if ($null -eq $plain) { Send $ctx 423 'text/plain' 'encrypted'; break }   # 다른 비밀번호로 잠긴 파일
        Send $ctx 200 'application/json; charset=utf-8' $plain
      }
      # ===== 🔒 비밀번호 정하기·바꾸기·없애기·지금 잠그기 =====
      '/api/lock' { $sessions.Clear(); $keys = $null; Log 'locked'; Json $ctx @{ok = $true } }
      '/api/pw/set' {
        $b = (ReadBody $req) | ConvertFrom-Json; $newPw = [string]$b.pw
        if ($newPw.Length -lt 4) { Json $ctx @{ok = $false; why = 'short' }; break }
        $oldK = $null
        if ($pwInfo) { $oldK = Check-Pw ([string]$b.old); if (-not $oldK) { Json $ctx @{ok = $false; why = 'wrong' }; break } }
        $salt = New-Rand 16; $iter = 200000; $newK = Derive $newPw $salt $iter
        New-Item -ItemType Directory -Force $projDir | Out-Null
        $n = Rewrap $oldK $newK
        $info = [ordered]@{v = 1; salt = [Convert]::ToBase64String($salt); iter = $iter; verify = [Convert]::ToBase64String([byte[]]$newK.verify); hint = ([string]$b.hint).Substring(0, [math]::Min(60, ([string]$b.hint).Length)); autolock = [int]$b.autolock }
        [IO.File]::WriteAllText($pwFile, ($info | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
        $pwInfo = Get-Content -LiteralPath $pwFile -Raw -Encoding utf8 | ConvertFrom-Json; $keys = $newK
        $sid = ([Convert]::ToBase64String((New-Rand 24))) -replace '[+/=]', ''; $sessions.Clear(); $sessions.Add($sid) | Out-Null
        $ctx.Response.Headers.Add('Set-Cookie', "vpes=$sid; Path=/; HttpOnly; SameSite=Strict")
        Log "password set (files rewrapped: $n)"; Json $ctx @{ok = $true; files = $n }
      }
      '/api/pw/autolock' {
        if (-not $pwInfo) { Json $ctx @{ok = $false }; break }
        $b = (ReadBody $req) | ConvertFrom-Json; $pwInfo.autolock = [int]$b.autolock
        [IO.File]::WriteAllText($pwFile, ($pwInfo | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false)); Json $ctx @{ok = $true }
      }
      '/api/pw/remove' {
        $b = (ReadBody $req) | ConvertFrom-Json; $oldK = Check-Pw ([string]$b.old)
        if (-not $oldK) { Json $ctx @{ok = $false; why = 'wrong' }; break }
        $n = Rewrap $oldK $null
        Remove-Item -LiteralPath $pwFile -Force; $pwInfo = $null; $keys = $null; $sessions.Clear()
        Log "password removed (files decrypted: $n)"; Json $ctx @{ok = $true; files = $n }
      }
      '/api/log' {
        # 편집기에서 생긴 오류를 기록 (나중에 원인을 찾기 위해, 이 컴퓨터 안에만 저장)
        $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd(); $sr.Close()
        if ($txt.Length -gt 3000) { $txt = $txt.Substring(0, 3000) }
        Log ("editor-error: " + ($txt -replace "[\r\n]+", ' / ')); Json $ctx @{ok = $true }
      }
      '/api/diag/save' {
        # 🩺 점검용 자료 (2026-11-15): 사용자가 단추를 눌렀을 때만 · 클립 설정만 담김(그림·파일 이름·자막 글·비밀번호 없음) → 작업저장\점검용 (최근 10개)
        $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd(); $sr.Close()
        if ($txt.Length -lt 20 -or $txt.Length -gt 8MB -or $txt -notmatch '"점검용"') { Json $ctx @{ok = $false; why = 'bad' }; break }
        $dd = Join-Path $projDir '점검용'; New-Item -ItemType Directory -Force $dd | Out-Null
        $f = Join-Path $dd ("점검자료_{0:yyyy-MM-dd_HH시mm분ss초}.json" -f (Get-Date))
        [IO.File]::WriteAllText($f, $txt, (New-Object Text.UTF8Encoding($false)))
        Get-ChildItem -LiteralPath $dd -Filter '점검자료_*.json' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 10 | Remove-Item -Force -ErrorAction SilentlyContinue
        Json $ctx @{ok = $true; name = (Split-Path $f -Leaf) }
      }
      '/api/file' {
        # 바꾼 영상을 조금씩 나눠서 보내기 (큰 파일도 메모리를 적게 씀, 앞뒤로 이동 가능)
        $j = $jobs[$q['id']]
        if (-not $j -or $j.state -ne 'done' -or -not (Test-Path $j.final)) { Send $ctx 404 'text/plain' 'not ready'; break }
        Stream-Async $ctx $j.final   # ⚡ 따로 일하는 일꾼이 보냄 → 재생 중에 다음 클립·저장 요청이 기다리지 않음
      }
      # ===== 🏆 완성 영상 보관함 =====
      '/api/done/list' {
        $meta = Read-DoneMeta
        $items = @(Get-ChildItem -LiteralPath $doneDir -File | Where-Object { $_.Extension -match '^\.(mp4|webm|mov)$' } | Sort-Object LastWriteTime -Descending | ForEach-Object {
          $m = $meta.($_.Name)
          @{name = $_.Name; path = $_.FullName; size = $_.Length; time = $_.LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss'); meta = $m }
        })
        Json $ctx @{dir = $doneDir; items = $items }
      }
      '/api/done/play' { $p = Done-File $q['name']; if (-not $p) { Send $ctx 404 'text/plain' 'no'; break }; Stream-Async $ctx $p }
      '/api/done/meta' {
        # 영상마다 기록(제목·메모·별표·만든 정보)을 숨김 파일 하나에 모아 둠
        $b = ReadBody $req | ConvertFrom-Json; $p = Done-File $b.name; if (-not $p) { Json $ctx @{ok = $false }; break }
        $meta = Read-DoneMeta; $nm = [IO.Path]::GetFileName($p); $cur = $meta.$nm
        if (-not $cur) { $cur = New-Object PSObject; $meta | Add-Member -NotePropertyName $nm -NotePropertyValue $cur -Force }
        foreach ($pr in $b.data.PSObject.Properties) { $v = $pr.Value; if ($v -is [string] -and $v.Length -gt 2000) { $v = $v.Substring(0, 2000) }; $cur | Add-Member -NotePropertyName $pr.Name -NotePropertyValue $v -Force }
        Write-DoneMeta $meta; Json $ctx @{ok = $true }
      }
      '/api/done/rename' {
        $p = Done-File $q['name']; $to = ([string]$q['to']) -replace '[\\/:*?"<>|]', '_'
        if (-not $p -or -not $to.Trim()) { Json $ctx @{ok = $false; msg = 'bad' }; break }
        $ext = [IO.Path]::GetExtension($p); if (-not $to.EndsWith($ext, [StringComparison]::OrdinalIgnoreCase)) { $to = $to.Trim() + $ext }
        $dest = Join-Path $doneDir $to; if (Test-Path -LiteralPath $dest) { Json $ctx @{ok = $false; msg = 'exists' }; break }
        Rename-Item -LiteralPath $p -NewName $to
        $meta = Read-DoneMeta; $old = [IO.Path]::GetFileName($p); $m = $meta.$old
        if ($m) { $meta.PSObject.Properties.Remove($old); $meta | Add-Member -NotePropertyName $to -NotePropertyValue $m -Force; Write-DoneMeta $meta }
        Log "done rename $old -> $to"; Json $ctx @{ok = $true; name = $to; path = $dest }
      }
      '/api/done/trash' {
        # 지우기는 항상 「휴지통」으로 (휴지통에서 되살릴 수 있음)
        $p = Done-File $q['name']; if (-not $p) { Json $ctx @{ok = $false }; break }
        Add-Type -AssemblyName Microsoft.VisualBasic
        [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
        Log "done trash $p"; Json $ctx @{ok = -not (Test-Path -LiteralPath $p) }
      }
      '/api/autosub' {
        if (-not (Voice-Ready)) { Json $ctx @{ ok = $false; error = 'nomodel' }; break }
        $p = $null; $jj = $jobs[[string]$q['id']]; if ($jj -and $jj.final -and (Test-Path -LiteralPath $jj.final)) { $p = $jj.final }
        if (-not $p -and $q['name']) { $want = 0; [void][int64]::TryParse([string]$q['size'], [ref]$want); $f = Find-Media ([string]$q['name']) $want; if ($f) { $p = $f.FullName } }
        if (-not $p) { Json $ctx @{ ok = $false; error = 'nofile' }; break }
        $inv = [Globalization.CultureInfo]::InvariantCulture; $ss = [double]::Parse([string]$q['ss'], $inv).ToString('0.###', $inv); $du = [double]::Parse([string]$q['dur'], $inv).ToString('0.###', $inv)
        Log "autosub $p $ss+$du"; Sub-Async $ctx $p $ss $du ([string]$q['prompt'])
      }
      '/api/voice/warm' { if (-not (Voice-Ready)) { Json $ctx @{ ok = $false; error = 'nomodel' }; break }; Voice-Async $ctx $null $null }
      '/api/voice' {
        if (-not (Voice-Ready)) { Json $ctx @{ ok = $false; error = 'nomodel' }; break }
        $wav = Join-Path $tmp ("voice_" + [guid]::NewGuid().ToString('N') + '.wav'); $fs = [IO.File]::Create($wav); try { $req.InputStream.CopyTo($fs, 1MB) } finally { $fs.Close() }
        Voice-Async $ctx $wav ([string]$q['prompt'])
      }
      # ===== 📱 같은 와이파이에서 열기 (이 PC에서만 켜고 끔) =====
      '/api/lan/info' {
        if ($req.Headers['X-VPE-Remote']) { Json $ctx @{ ok = $false }; break }
        $on = [bool]($lan -and $lan.On -and (Get-Date) -lt $lan.Until)
        Json $ctx @{ on = $on; urls = $(if ($on) { @(Lan-Urls $lan.Port) } else { @() }); pin = $(if ($on) { $lan.Pin } else { '' }); until = $(if ($on) { $lan.Until.ToString('HH:mm') } else { '' }); sessions = $(if ($on) { $lan.Sessions } else { 0 }); seen = $(if ($on) { $lan.Seen.Count } else { 0 }) }
      }
      '/api/lan/start' {
        if ($req.Headers['X-VPE-Remote']) { Json $ctx @{ ok = $false }; break }
        try {
          if (-not ('VpeLan' -as [type])) { Add-Type -TypeDefinition $lanType -ReferencedAssemblies System.Net.Http }
          if ($lan) { $lan.Stop() }
          $lan = New-Object VpeLan; $lan.Target = $Port; $lan.PinPage = $lanPinPage; $lan.LoopOnly = [bool]$LanTest
          $rb = New-Rand 4; $lan.Pin = ('{0:D6}' -f ([BitConverter]::ToUInt32($rb, 0) % 1000000)); $lan.Until = (Get-Date).AddHours(2)
          $okp = $false; foreach ($lp in 48700..48710) { try { $lan.Port = $lp; $lan.Start(); $okp = $true; break } catch {} }
          if (-not $okp) { Json $ctx @{ ok = $false; why = 'port' }; break }
          Log "lan on port=$($lan.Port)"; Json $ctx @{ ok = $true; urls = @(Lan-Urls $lan.Port); pin = $lan.Pin; until = $lan.Until.ToString('HH:mm') }
        } catch { Log "lan start error: $_"; Json $ctx @{ ok = $false; why = "$_" } }
      }
      '/api/lan/stop' { if ($req.Headers['X-VPE-Remote']) { Json $ctx @{ ok = $false }; break }; if ($lan) { $lan.Stop(); Log 'lan off' }; Json $ctx @{ ok = $true } }
      # ===== ☁ 클라우드 백업 (선택) =====
      '/api/cloud/info' {
        $cd = Cloud-Dir
        Json $ctx @{ roots = (Cloud-Roots); cloud = [string]$link.cloud; cloudDone = [bool]$link.cloudDone; dir = $cd; last = $cloudState.last; err = $cloudState.err; busy = [int]$cloudState.busy; pw = [bool]$pwInfo }
      }
      '/api/cloud/set' {
        $b = (ReadBody $req) | ConvertFrom-Json; $p = [string]$b.path
        if ($p) { $p = Ok-Folder $p; if (-not $p) { Json $ctx @{ ok = $false; why = 'badpath' }; break } }
        $link.cloud = $(if ($p) { $p } else { '' }); $link.cloudDone = [bool]$b.done; Save-Link
        if ($p) { $latest = Join-Path $projDir '자동저장_최근.vpe.json'; if (Test-Path -LiteralPath $latest) { Cloud-Project $latest $null } }   # 켜자마자 지금 작업을 한 벌 올림
        Log "cloud set '$($link.cloud)' done=$($link.cloudDone)"; Json $ctx @{ ok = $true; dir = (Cloud-Dir); last = $cloudState.last }
      }
      '/api/cloud/list' {
        $cd = Cloud-Dir; if (-not $cd) { Json $ctx @{ items = @() }; break }
        $items = @(Get-ChildItem -LiteralPath (Join-Path $cd '작업저장') -Filter '*.vpe.json' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 40 | ForEach-Object { @{ name = $_.Name; time = [long](($_.LastWriteTimeUtc - [datetime]'1970-01-01').TotalMilliseconds); size = $_.Length } })
        Json $ctx @{ items = $items }
      }
      '/api/cloud/load' {
        $cd = Cloud-Dir; $nm = [IO.Path]::GetFileName([string]$q['name']); if (-not $cd -or -not $nm -or $nm -notmatch '\.vpe\.json$') { Send $ctx 404 'text/plain' 'no'; break }
        $p = Join-Path (Join-Path $cd '작업저장') $nm; if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { Send $ctx 404 'text/plain' 'no'; break }
        $plain = Dec-Text ([IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)) $keys
        if ($null -eq $plain) { Send $ctx 423 'text/plain' 'encrypted'; break }
        Send $ctx 200 'application/json; charset=utf-8' $plain
      }
      '/api/cloud/open' { $cd = Cloud-Dir; if ($cd) { New-Item -ItemType Directory -Force $cd | Out-Null; if ($q['dry'] -ne '1') { Start-Process explorer.exe "`"$cd`"" } }; Json $ctx @{ ok = [bool]$cd } }
      # ===== 📁 폴더 고르기 창 =====
      '/api/pickfolder' { Json $ctx @{ id = (Start-PickFolder) } }
      '/api/pickfolder/status' {
        $j = $jobs[[string]$q['id']]; if (-not $j -or -not $j.pick) { Json $ctx @{ state = 'error' }; break }
        if (-not $j.proc.HasExited) { Json $ctx @{ state = 'running' }; break }
        $p = ''; if (Test-Path -LiteralPath $j.pick) { $p = ([IO.File]::ReadAllText($j.pick, [Text.Encoding]::UTF8)).Trim(); Remove-Item -LiteralPath $j.pick -Force -ErrorAction SilentlyContinue }
        $jobs.Remove($j.id); Json $ctx @{ state = 'done'; path = $p; ok = [bool](Ok-Folder $p) }
      }
      # ===== 🔄 자동 업데이트 =====
      '/api/update/info' {
        $vf = Join-Path $root 'tools\version.json'; $v = $null; if (Test-Path -LiteralPath $vf) { try { $v = Get-Content -LiteralPath $vf -Raw -Encoding utf8 | ConvertFrom-Json } catch {} }
        $sf = Join-Path $projDir '.업데이트상태.json'; $last = $null; if (Test-Path -LiteralPath $sf) { try { $last = Get-Content -LiteralPath $sf -Raw -Encoding utf8 | ConvertFrom-Json } catch {} }
        $owner = Test-Path -LiteralPath (Join-Path $(if ($env:VPE_KEYDIR) { $env:VPE_KEYDIR } else { Join-Path $env:LOCALAPPDATA '영상사진편집기_서명키' }) 'private.bin')
        Json $ctx @{ ver = $(if ($v) { [string]$v.version } else { '' }); verNotes = $(if ($v) { [string]$v.notes } else { '' }); key = (Test-Path -LiteralPath (Join-Path $root 'tools\update_pub.xml')); owner = $owner
          busy = [bool]$updState.busy; state = [string]$updState.state; why = [string]$updState.why; checked = [string]$updState.checked; team = [bool](Team-Dir); folder = [string]$link.upd; last = $last }
      }
      # 🛡 원본 확인 (공유받은 편집기를 누가 고쳤는지 · 만든 사람 PC에서는 'owner')
      '/api/integrity' {
        if (-not (Test-Path -LiteralPath $updScriptF)) { Json $ctx @{ state = 'unknown' }; break }
        . $updScriptF; $r = Test-VpeRelease -Root $root
        if ($r.state -eq 'tampered') { Log "integrity tampered: $($r.why)" }
        Json $ctx @{ state = [string]$r.state; why = [string]$r.why; sid = [string]$r.sid }
      }
      '/api/update/check' { $nextUpd = (Get-Date).AddMinutes(30); Start-UpdCheck; Json $ctx @{ ok = $true } }
      '/api/update/seen' {
        $sf = Join-Path $projDir '.업데이트상태.json'
        if (Test-Path -LiteralPath $sf) { try { $o = Get-Content -LiteralPath $sf -Raw -Encoding utf8 | ConvertFrom-Json; $o.seen = $true; [IO.File]::WriteAllText($sf, ($o | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false)) } catch {} }
        Json $ctx @{ ok = $true }
      }
      '/api/update/set' {
        $b = (ReadBody $req) | ConvertFrom-Json; $p = [string]$b.path
        if ($p) { $p = Ok-Folder $p; if (-not $p) { Json $ctx @{ ok = $false; why = 'badpath' }; break } }
        $link.upd = $(if ($p) { $p } else { '' }); Save-Link; Log "update folder '$($link.upd)'"
        $nextUpd = (Get-Date).AddMinutes(30); Start-UpdCheck; Json $ctx @{ ok = $true; dir = $link.upd }
      }
      # ===== 👥 팀 작업 폴더 (여러 사람이 각자 맡은 부분을 올리고, 모아서 한 영상으로) =====
      '/api/team/info' {
        $td = Team-Dir; $n = 0; if ($td) { $n = @(Get-ChildItem -LiteralPath (Join-Path $td '부분') -Filter '*.vpepart.json' -ErrorAction SilentlyContinue).Count }
        Json $ctx @{ team = [string]$link.team; me = [string]$link.me; dir = $td; parts = $n; roots = (Cloud-Roots); copying = [int]$teamState.busy; copied = [int]$teamState.done; err = $teamState.err }
      }
      '/api/team/set' {
        $b = (ReadBody $req) | ConvertFrom-Json; $p = [string]$b.path
        if ($p) { $p = Ok-Folder $p; if (-not $p) { Json $ctx @{ ok = $false; why = 'badpath' }; break } }
        $me = (([string]$b.me) -replace '[\\/:*?"<>|_\r\n\t]', '').Trim(); if ($me.Length -gt 20) { $me = $me.Substring(0, 20) }
        if ($p -and -not $me) { Json $ctx @{ ok = $false; why = 'noname' }; break }
        $link.team = $(if ($p) { $p } else { '' }); $link.me = $me; Save-Link
        $td = Team-Dir; if ($td) { foreach ($s in @('부분', '자료')) { New-Item -ItemType Directory -Force (Join-Path $td $s) | Out-Null }
          $rd = Join-Path $td '읽어 주세요.txt'; if (-not (Test-Path -LiteralPath $rd)) { [IO.File]::WriteAllText($rd, "영상·사진 편집기 팀 작업 폴더예요.`r`n- 부분: 팀원마다 맡은 부분(클립 순서·효과·자막)을 올린 파일`r`n- 자료: 그 부분에 쓴 영상·사진·음악 원본`r`n편집기의 「👥 함께 편집」에서 올리고 모아요. 이 폴더를 팀원과 공유(OneDrive·구글 드라이브 공유, USB 등)하세요.", (New-Object Text.UTF8Encoding $true)) } }
        Log "team set '$($link.team)' me=$me"; Json $ctx @{ ok = $true; dir = $td }
      }
      '/api/team/put' {
        $td = Team-Dir; if (-not $td -or -not $link.me) { Json $ctx @{ ok = $false; why = 'noteam' }; break }
        # 몸통: 부분 내용(JSON 글자 그대로 · 큰 파일도 되도록 풀지 않고 씀) / 주소: 제목·요약
        $txt = ReadBody $req; $t0 = $txt.TrimStart()
        if ($txt.Length -lt 20 -or -not $t0.StartsWith('{') -or $txt -notmatch '"clips"\s*:\s*\[\s*\{') { Json $ctx @{ ok = $false; why = 'empty' }; break }
        $title = (([string]$q['title']) -replace '[\\/:*?"<>|_\r\n\t]', ' ').Trim(); if (-not $title) { $title = '내 부분' }; if ($title.Length -gt 30) { $title = $title.Substring(0, 30) }
        $pd = Join-Path $td '부분'; New-Item -ItemType Directory -Force $pd | Out-Null
        $file = Join-Path $pd ("{0}__{1}.vpepart.json" -f $link.me, $title)
        $now = [long](((Get-Date).ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds)
        $head = @{ v = 1; author = [string]$link.me; title = $title; time = $now } | ConvertTo-Json -Compress
        [IO.File]::WriteAllText("$file.tmp", ($head.TrimEnd('}') + ',"part":' + $txt + '}'), (New-Object Text.UTF8Encoding $false)); Move-Item -LiteralPath "$file.tmp" -Destination $file -Force
        $meta = @{ author = [string]$link.me; title = $title; time = $now; clips = [int]$q['clips']; texts = [int]$q['texts']; dur = [double]$q['dur'] } | ConvertTo-Json -Compress
        [IO.File]::WriteAllText("$file.meta", $meta, (New-Object Text.UTF8Encoding $false))
        Log "team put $file"; Json $ctx @{ ok = $true; file = [IO.Path]::GetFileName($file) }
      }
      '/api/team/copy' {
        # 쓴 자료(영상·사진·음악)를 팀 폴더 「자료」에 복사 (이미 같은 것이 있으면 건너뜀) · 몸통: [{name,size,convName,convSize,local}]
        $td = Team-Dir; if (-not $td) { Json $ctx @{ ok = $false; why = 'noteam' }; break }
        $list = (ReadBody $req) | ConvertFrom-Json
        $pairs = New-Object System.Collections.ArrayList; $miss = @(); $dd = Join-Path $td '자료'
        foreach ($m in @($list)) {
          if (-not $m -or -not $m.name -or $m.gen) { continue }
          $src = $null
          foreach ($c in @(@([string]$m.name, [int64]$m.size), @([string]$m.convName, [int64]$m.convSize), @([string]$m.local, 0))) {
            if (-not $c[0] -or $c[0] -notmatch $mediaExt) { continue }
            $o = Join-Path $outDir ([IO.Path]::GetFileName($c[0])); if (Test-Path -LiteralPath $o -PathType Leaf) { $src = $o; break }
            $f = Find-Media ([IO.Path]::GetFileName($c[0])) $c[1] -Quick; if ($f) { $src = $f.FullName; break }
          }
          if (-not $src) { $f = Find-Media ([IO.Path]::GetFileName([string]$m.name)) ([int64]$m.size); if ($f) { $src = $f.FullName } }
          if ($src) { if (-not $src.StartsWith($dd, [StringComparison]::OrdinalIgnoreCase)) { [void]$pairs.Add(@($src, (Join-Path $dd ([IO.Path]::GetFileName($src))))) } } else { $miss += [string]$m.name }
        }
        $teamState.err = ''; Copy-Async $pairs.ToArray() $teamState
        Log "team copy $($pairs.Count), miss $($miss.Count)"; Json $ctx @{ ok = $true; copy = $pairs.Count; miss = $miss }
      }
      '/api/team/list' {
        $td = Team-Dir; if (-not $td) { Json $ctx @{ items = @() }; break }
        $items = @(Get-ChildItem -LiteralPath (Join-Path $td '부분') -Filter '*.vpepart.json' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | ForEach-Object {
          $o = $null; try { $o = [IO.File]::ReadAllText("$($_.FullName).meta", [Text.Encoding]::UTF8) | ConvertFrom-Json } catch {}
          if (-not $o) { $o = @{ author = ($_.Name -split '__')[0]; title = (($_.Name -split '__', 2)[-1] -replace '\.vpepart\.json$', ''); time = [long](($_.LastWriteTimeUtc - [datetime]'1970-01-01').TotalMilliseconds) } }   # 요약이 없으면 파일 이름으로
          @{ name = $_.Name; author = [string]$o.author; title = [string]$o.title; time = [long]$o.time; clips = [int]$o.clips; texts = [int]$o.texts; dur = [double]$o.dur; mine = ([string]$o.author -eq $link.me) } })
        Json $ctx @{ items = $items; me = $link.me }
      }
      '/api/team/get' {
        $td = Team-Dir; $nm = [IO.Path]::GetFileName([string]$q['name']); if (-not $td -or $nm -notmatch '\.vpepart\.json$') { Send $ctx 404 'text/plain' 'no'; break }
        $p = Join-Path (Join-Path $td '부분') $nm; if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { Send $ctx 404 'text/plain' 'no'; break }
        Send $ctx 200 'application/json; charset=utf-8' ([IO.File]::ReadAllText($p, [Text.Encoding]::UTF8))
      }
      '/api/team/remove' {
        # 내가 올린 부분만, 지우지 않고 「치운_부분」 폴더로 옮김 (되살릴 수 있게)
        $td = Team-Dir; $nm = [IO.Path]::GetFileName([string]$q['name']); if (-not $td -or $nm -notmatch '\.vpepart\.json$' -or -not $nm.StartsWith("$($link.me)__")) { Json $ctx @{ ok = $false }; break }
        $p = Join-Path (Join-Path $td '부분') $nm; if (-not (Test-Path -LiteralPath $p)) { Json $ctx @{ ok = $false }; break }
        $bin = Join-Path $td '치운_부분'; New-Item -ItemType Directory -Force $bin | Out-Null
        Move-Item -LiteralPath $p -Destination (Join-Path $bin ("{0:yyyyMMdd_HHmmss}_{1}" -f (Get-Date), $nm)) -Force
        if (Test-Path -LiteralPath "$p.meta") { Move-Item -LiteralPath "$p.meta" -Destination (Join-Path $bin ("{0:yyyyMMdd_HHmmss}_{1}.meta" -f (Get-Date), $nm)) -Force }; Json $ctx @{ ok = $true }
      }
      # ===== 🐞 문제·의견 보내기 =====
      '/api/feedback/log' {
        # 최근 오류 기록만 (파일 위치는 이름만 남기고, 사용자 폴더 이름은 가림)
        $lines = @(); if (Test-Path -LiteralPath $logFile) { $lines = @(Get-Content -LiteralPath $logFile -Tail 400 -Encoding utf8 | Where-Object { $_ -match 'error|오류|fail|blocked|integrity' } | Select-Object -Last 30) }
        $user = [regex]::Escape($env:USERNAME)
        $clean = @($lines | ForEach-Object { ($_ -replace '[A-Za-z]:\\[^\s"'']*\\([^\\\s"'']+)', '…\$1') -replace $user, '(사용자)' })
        Json $ctx @{ lines = $clean; version = $HelperVersion; ffmpeg = [bool]$ff; voice = [bool](Voice-Ready); os = [Environment]::OSVersion.VersionString; cpu = [Environment]::ProcessorCount }
      }
      '/api/feedback/save' {
        # 편집기가 만든 의견 묶음(zip)을 「팀_주고받기」 폴더에 저장 → 카톡으로 보내기 쉽게
        $nm = (([string]$q['name']) -replace '[\\/:*?"<>|\r\n\t]', ' ').Trim(); if (-not $nm) { $nm = '팀원' }; if ($nm.Length -gt 20) { $nm = $nm.Substring(0, 20) }
        $pdir = Join-Path $root '팀_주고받기'; New-Item -ItemType Directory -Force $pdir | Out-Null
        $out = Join-Path $pdir ("의견_{0}_{1:yyyyMMdd_HHmm}.zip" -f $nm, (Get-Date)); $k = 2; while (Test-Path -LiteralPath $out) { $out = Join-Path $pdir ("의견_{0}_{1:yyyyMMdd_HHmm}({2}).zip" -f $nm, (Get-Date), $k); $k++ }
        $fs = [IO.File]::Create($out); try { $req.InputStream.CopyTo($fs, 1MB) } finally { $fs.Close() }
        if ((Get-Item -LiteralPath $out).Length -gt 60MB) { Remove-Item -LiteralPath $out -Force; Json $ctx @{ ok = $false; why = 'big' }; break }
        Log "feedback saved $out"; Json $ctx @{ ok = $true; path = $out; name = [IO.Path]::GetFileName($out); size = (Get-Item -LiteralPath $out).Length }
      }
      # ===== 📦 카톡·메일로 부분 주고받기 (공유 폴더 없이 파일 하나로) =====
      '/api/part/pack' {
        # 몸통: 부분 내용(JSON 글자 그대로) · 주소: title, author, media(1/0), list(=[{name,size}] JSON)
        $txt = ReadBody $req; if ($txt.Length -lt 20 -or -not $txt.TrimStart().StartsWith('{')) { Json $ctx @{ ok = $false; why = 'empty' }; break }
        $clean = { param($s, $n) $v = (([string]$s) -replace '[\\/:*?"<>|_\r\n\t]', ' ').Trim(); if ($v.Length -gt $n) { $v = $v.Substring(0, $n) }; $v }
        $title = & $clean $q['title'] 30; if (-not $title) { $title = '내 부분' }; $author = & $clean $q['author'] 20; if (-not $author) { $author = '팀원' }
        $pdir = Join-Path $root '팀_주고받기'; New-Item -ItemType Directory -Force $pdir | Out-Null
        $zip = Join-Path $pdir ("{0}_{1}.zip" -f $author, $title); $k = 2; while (Test-Path -LiteralPath $zip) { $zip = Join-Path $pdir ("{0}_{1}({2}).zip" -f $author, $title, $k); $k++ }
        $now = [long](((Get-Date).ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds)
        $head = @{ v = 1; author = $author; title = $title; time = $now } | ConvertTo-Json -Compress
        $json = $head.TrimEnd('}') + ',"part":' + $txt + '}'
        $files = New-Object System.Collections.ArrayList; $miss = @()
        # 자료가 많으면 주소가 너무 길어져서(한글 이름) 편집기가 list를 빼고 보냄 → 그때는 몸통의 media 목록을 씀
        $mlist = $null
        if ($q['media'] -eq '1' -and $q['list']) { $mlist = ([string]$q['list']) | ConvertFrom-Json }   # (바로 @( )로 감싸면 목록 전체가 한 덩어리가 되어 따로 받아 둠)
        elseif ($q['media'] -eq '1') { try { $pj = $txt | ConvertFrom-Json; $mlist = @($pj.media | Where-Object { $_ -and -not $_.gen } | ForEach-Object { [pscustomobject]@{ name = $_.name; size = $_.size } }) } catch { $mlist = $null } }
        if ($mlist) {
          foreach ($m in $mlist) {
            if (-not $m.name -or $m.name -notmatch $mediaExt) { continue }
            $nm = [IO.Path]::GetFileName([string]$m.name); $src = $null
            $o = Join-Path $outDir $nm; if (Test-Path -LiteralPath $o -PathType Leaf) { $src = $o }
            if (-not $src) { $f = Find-Media $nm ([int64]$m.size) -Quick; if (-not $f) { $f = Find-Media $nm ([int64]$m.size) }; if ($f) { $src = $f.FullName } }
            if ($src) { [void]$files.Add($src) } else { $miss += $nm }
          }
        }
        $id = [guid]::NewGuid().ToString('N'); $st = [hashtable]::Synchronized(@{ state = 'running'; pct = 0; err = '' })
        $packScript = {
          param($zip, $json, $files, $st)
          try {
            Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
            $fs = [IO.File]::Create("$zip.making"); $za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create, $false, [Text.Encoding]::UTF8)
            $e = $za.CreateEntry('부분.vpepart.json'); $w = New-Object IO.StreamWriter($e.Open(), (New-Object Text.UTF8Encoding $false)); $w.Write($json); $w.Close()
            $i = 0; $seen = @{}
            foreach ($f in $files) { $n = [IO.Path]::GetFileName($f); if ($seen[$n]) { continue }; $seen[$n] = 1
              [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($za, $f, "자료/$n", [IO.Compression.CompressionLevel]::NoCompression); $i++; $st.pct = [int](100 * $i / [math]::Max(1, $files.Count)) }
            $za.Dispose(); $fs.Close(); Move-Item -LiteralPath "$zip.making" -Destination $zip -Force
            $st.size = (Get-Item -LiteralPath $zip).Length; $st.state = 'done'
          } catch { $st.err = "$_"; $st.state = 'error'; try { $fs.Close() } catch {}; Remove-Item -LiteralPath "$zip.making" -Force -ErrorAction SilentlyContinue }
        }
        Prune-Streams; $ps = [PowerShell]::Create(); $ps.RunspacePool = $streamPool
        [void]$ps.AddScript($packScript).AddArgument($zip).AddArgument($json).AddArgument($files.ToArray()).AddArgument($st); [void]$streamJobs.Add(@{ ps = $ps; h = $ps.BeginInvoke() })
        $jobs[$id] = @{ id = $id; packSt = $st; path = $zip }
        Log "part pack $zip ($($files.Count) files, miss $($miss.Count))"; Json $ctx @{ ok = $true; id = $id; path = $zip; name = [IO.Path]::GetFileName($zip); files = $files.Count; miss = $miss }
      }
      '/api/part/status' { $j = $jobs[[string]$q['id']]; if (-not $j -or -not $j.packSt) { Json $ctx @{ state = 'error' }; break }; Json $ctx @{ state = $j.packSt.state; pct = $j.packSt.pct; size = [int64]$j.packSt.size; err = $j.packSt.err; path = $j.path } }
      '/api/part/unpack' {
        # 받은 부분 파일(zip)을 「받은_부분」 폴더에 안전하게 풀고, 부분 내용을 돌려줌 (부분 파일과 사진·영상·음악만 · 폴더 밖으로 못 나가게)
        $nm = ([IO.Path]::GetFileNameWithoutExtension([string]$q['name'])) -replace '[\\/:*?"<>|]', '_'; if (-not $nm) { $nm = '받은부분' }
        $tz = Join-Path $tmp ([guid]::NewGuid().ToString('N') + '.zip'); $fs = [IO.File]::Create($tz); try { $req.InputStream.CopyTo($fs, 4MB) } finally { $fs.Close() }
        $dest = Join-Path (Join-Path $root '받은_부분') $nm; $k = 2; while (Test-Path -LiteralPath $dest) { $dest = Join-Path (Join-Path $root '받은_부분') ("{0}({1})" -f $nm, $k); $k++ }
        $partTxt = $null
        try {
          Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
          $za = [IO.Compression.ZipFile]::OpenRead($tz)
          try {
            New-Item -ItemType Directory -Force (Join-Path $dest '자료') | Out-Null
            foreach ($e in $za.Entries) {
              $en = $e.FullName -replace '\\', '/'
              if ($en -match '(^|/)\.\.(/|$)' -or $en.StartsWith('/')) { continue }
              if ($en -match '\.vpepart\.json$' -and -not $partTxt) { $sr = New-Object IO.StreamReader($e.Open(), [Text.Encoding]::UTF8); $partTxt = $sr.ReadToEnd(); $sr.Close(); continue }
              $fn = [IO.Path]::GetFileName($en); if (-not $fn -or $fn -notmatch $mediaExt) { continue }
              [IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path (Join-Path $dest '자료') $fn), $true)
            }
          } finally { $za.Dispose() }
        } catch { Log "part unpack error: $_"; $partTxt = $null }
        Remove-Item -LiteralPath $tz -Force -ErrorAction SilentlyContinue
        if (-not $partTxt) { Json $ctx @{ ok = $false; why = 'notpart' }; break }
        [IO.File]::WriteAllText((Join-Path $dest '부분.vpepart.json'), $partTxt, (New-Object Text.UTF8Encoding $false))
        Log "part unpack -> $dest"; Send $ctx 200 'application/json; charset=utf-8' $partTxt
      }
      '/api/team/open' { $td = Team-Dir; if ($td -and $q['dry'] -ne '1') { Start-Process explorer.exe "`"$td`"" }; Json $ctx @{ ok = [bool]$td } }
      '/api/done/folder' { if ($q['dry'] -ne '1') { Start-Process explorer.exe "`"$doneDir`"" }; Json $ctx @{ok = $true } }
      default { Send $ctx 404 'text/plain' 'not found' }
    }
  } catch {
    Log "req error $path : $_"
    try { Send $ctx 500 'text/plain' 'error' } catch {}
  }
}
