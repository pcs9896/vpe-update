﻿# 처음 설치하기: 받은 편집기를 이 컴퓨터에서 쓸 수 있게 준비합니다. (한 번만)
param([switch]$NoShortcut, [switch]$NoAsk)
$Host.UI.RawUI.WindowTitle = '영상·사진 편집기 - 처음 설치하기'
$root = Split-Path $PSScriptRoot -Parent
Write-Host ''
Write-Host '  ===== 영상·사진 편집기 처음 설치하기 =====' -ForegroundColor Green
Write-Host '  이 프로그램은 인터넷에 아무것도 보내지 않고, 이 컴퓨터 안에서만 동작해요.'
Write-Host ''

# 1) 인터넷에서 받은 파일 표시 풀기 (실행할 때마다 경고가 뜨지 않게)
Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
Write-Host '  ✔ 받은 파일 준비 완료'

# 2) 🔒 변조 검사
$sumFile = Join-Path $PSScriptRoot 'checksums.sha256'
if (Test-Path $sumFile) {
  $bad = @()
  foreach ($line in Get-Content $sumFile -Encoding utf8) {
    if ($line -notmatch '^([0-9a-f]{64})\s+\*?(.+)$') { continue }
    $f = Join-Path $root $matches[2]
    if (-not (Test-Path -LiteralPath $f) -or (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower() -ne $matches[1]) { $bad += $matches[2] }
  }
  if ($bad.Count) {
    Write-Host ("  ⚠ 원래와 달라진 파일이 있어요: " + ($bad -join ', ')) -ForegroundColor Red
    Write-Host '    누군가 바꿨을 수 있어요. 보낸 사람에게 zip을 다시 받아 주세요. 설치를 멈춥니다.' -ForegroundColor Red
    if (-not $NoAsk) { Read-Host '  Enter 키를 누르면 닫혀요' | Out-Null }; exit 2
  }
  Write-Host '  ✔ 보안 확인: 프로그램 파일이 원래 그대로예요'
} else { Write-Host '  (보안 확인 목록이 없어서 건너뜀)' -ForegroundColor DarkGray }

# 3) 쓸 폴더 만들기
foreach ($d in '변환할_영상', '변환된_영상', '완성된_영상', '작업저장') { New-Item -ItemType Directory -Force (Join-Path $root $d) | Out-Null }

# 4) 엣지 확인
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($edge) { Write-Host '  ✔ 엣지 브라우저 있음' } else { Write-Host '  ⚠ 엣지가 없어서 기본 브라우저로 열려요. (크롬도 괜찮아요)' -ForegroundColor Yellow }

# 5) 바탕화면 바로가기 (이 폴더 위치에 맞게)
if (-not $NoShortcut) {
  $desk = [Environment]::GetFolderPath('Desktop')
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut((Join-Path $desk '영상사진 편집기.lnk'))
  $lnk.TargetPath = "$env:WINDIR\System32\wscript.exe"
  $lnk.Arguments = '"' + (Join-Path $PSScriptRoot 'start.vbs') + '"'
  $lnk.WorkingDirectory = $root
  $lnk.IconLocation = (Join-Path $PSScriptRoot 'icon.ico')
  $lnk.Description = '영상·사진 편집기 (이 컴퓨터 안에서만 동작)'
  $lnk.Save()
  Write-Host '  ✔ 바탕화면에 「영상사진 편집기」 아이콘을 만들었어요'
}

# 6) 드론·아이폰 영상(H.265) 변환 도구
$have = (Get-Command ffmpeg -ErrorAction SilentlyContinue) -or (Test-Path (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\ffmpeg.exe')) -or (Test-Path (Join-Path $root 'ffmpeg\bin\ffmpeg.exe')) -or
  [bool](Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') -Filter 'ffmpeg.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1)
if ($have) { Write-Host '  ✔ 영상 변환 도구(ffmpeg) 있음' }
elseif (-not $NoAsk) {
  Write-Host ''
  Write-Host '  드론·아이폰 영상(H.265)을 쓰려면 무료 변환 도구(ffmpeg, 약 100MB)가 필요해요.'
  $a = Read-Host '  지금 설치할까요? (Y = 예 / N = 나중에)'
  if ($a -match '^[yYㅛ]') { & (Join-Path $PSScriptRoot 'install.ps1') }
  else { Write-Host '  나중에 「변환도구_설치하기(처음 한 번만).bat」를 실행하면 돼요.' }
}
Write-Host ''
Write-Host '  ✅ 준비 끝! 바탕화면의 「영상사진 편집기」 아이콘을 더블클릭하세요.' -ForegroundColor Green
Write-Host ''
if (-not $NoAsk) { Read-Host '  Enter 키를 누르면 닫혀요' | Out-Null }
