﻿# 🔄 편집기 자동 업데이트 (공유받은 사람 쪽)
# - 만든 사람이 「업데이트_배포하기.bat」로 올린 새 버전을 찾아서, 서명이 맞을 때만 설치해요.
# - 어디서 찾나: ① 내 「👥 팀 작업 폴더」 안의 「업데이트」 폴더  ② 편집기에서 고른 「업데이트 받을 폴더」  ③ tools\update_source.txt 에 적힌 폴더·https 주소
# - 🔒 안전: 만든 사람의 비밀 열쇠로 서명된 것만 받음 (tools\update_pub.xml 공개 열쇠로 확인) · 파일마다 지문(SHA-256) 확인
#           정해진 프로그램 파일만 바꿈 (내 영상·작업·완성 영상은 건드리지 않음) · 바꾸기 전 지금 버전을 「작업저장\편집기_이전버전」에 보관
#           더 새로운 버전만 받음 (예전 버전으로 되돌리는 공격 막음) · 만든 사람 PC(비밀 열쇠가 있는 PC)에서는 동작하지 않음
# - 사용: . tools\updater.ps1; Invoke-VpeUpdate -Root <편집기 폴더> -Sources @(<폴더 또는 https 주소>)

$VpeUpdFiles = @(
  '영상사진편집기.html', '사용설명서.html', '사용설명서.txt', '저작권_및_오픈소스_고지.txt', '사용허락_조건.txt', '편집기 열기.vbs', '처음 설치하기.bat', '드론영상_변환하기.bat', '변환도구_설치하기(처음 한 번만).bat',
  'tools\helper.ps1', 'tools\convert.ps1', 'tools\install.ps1', 'tools\setup.ps1', 'tools\start.vbs', 'tools\icon.ico', 'tools\updater.ps1', 'tools\update_source.txt'
)
$VpeShareIdFiles = @('영상사진편집기.html', '사용허락_조건.txt', '저작권_및_오픈소스_고지.txt')

function Get-VpeKeyDir { if ($env:VPE_KEYDIR) { return $env:VPE_KEYDIR }; Join-Path $env:LOCALAPPDATA '영상사진편집기_서명키' }   # VPE_KEYDIR: 자동 점검용
# 🕵 숨은 배포 번호: 보이는 번호(__SHAREID__)와 별도로 16진수로 바꾼 번호(__SHAREHX__)를 코드 속에 넣어 둠 → 보이는 번호만 지우거나 바꾸면 들통남
function Get-VpeHx([string]$Sid) { -join ([Text.Encoding]::UTF8.GetBytes($Sid) | ForEach-Object { '{0:x2}' -f $_ }) }
function Set-VpeShareId([string]$Text, [string]$Sid) { $Text.Replace('__SHAREID__', $Sid).Replace('__SHAREHX__', (Get-VpeHx $Sid)) }
function Get-VpeShareIdOf([string]$Html) { $mm = [regex]::Match($Html, "const LIC = \{owner:'[^']*', id:'([^']+)'"); if ($mm.Success -and $mm.Groups[1].Value -ne '__SHAREID__') { return ($mm.Groups[1].Value -replace '[^A-Za-z0-9\-]', '') }; return '' }
function Get-VpeSha([byte[]]$b) { $h = [Security.Cryptography.SHA256]::Create(); try { -join ($h.ComputeHash($b) | ForEach-Object { '{0:x2}' -f $_ }) } finally { $h.Dispose() } }
function Get-VpeLocalVersion($Root) {
  $vf = Join-Path $Root 'tools\version.json'
  if (Test-Path -LiteralPath $vf) { try { $v = [string]((Get-Content -LiteralPath $vf -Raw -Encoding utf8 | ConvertFrom-Json).version); if ($v -match '^\d{12}$') { return $v } } catch {} }
  return '000000000000'
}
# 소스에서 파일 하나 읽기 (폴더 또는 https 주소)
function Read-VpeSrc([string]$Src, [string]$Name) {
  if ($Src -match '^https://') {
    $u = $Src.TrimEnd('/') + '/' + $Name
    try { $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 60 } catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 404) { return $null }; throw }
    return , $r.RawContentStream.ToArray()   # 글자로 바꾸지 않은 그대로 (서명 확인이 정확하도록)
  }
  $p = Join-Path $Src $Name
  if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return $null }
  return , [IO.File]::ReadAllBytes($p)
}
function Test-VpeSig([byte[]]$Data, [byte[]]$Sig, [string]$PubXml) {
  $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
  try { $rsa.PersistKeyInCsp = $false; $rsa.FromXmlString($PubXml); return $rsa.VerifyData($Data, 'SHA256', $Sig) } catch { return $false } finally { $rsa.Dispose() }
}
# 업데이트 받을 곳 목록
function Get-VpeUpdSources($Root, $TeamDir, $Extra) {
  $s = New-Object System.Collections.ArrayList
  if ($TeamDir) { [void]$s.Add((Join-Path $TeamDir '업데이트')) }
  foreach ($e in @($Extra)) { if ($e) { [void]$s.Add([string]$e) } }
  $sf = Join-Path $Root 'tools\update_source.txt'
  if (Test-Path -LiteralPath $sf) { foreach ($ln in [IO.File]::ReadAllLines($sf, [Text.Encoding]::UTF8)) { $t = $ln.Trim(); if ($t -and -not $t.StartsWith('#')) { [void]$s.Add($t) } } }
  return , @($s | Select-Object -Unique)
}

function Invoke-VpeUpdate {
  param([string]$Root, [string[]]$Sources = @(), [string]$KeyDir = '', [string]$StateDir = '')
  $res = @{ state = 'none'; from = ''; to = ''; notes = ''; why = ''; checked = (Get-Date).ToString('yyyy-MM-dd HH:mm') }
  try {
    if (-not $KeyDir) { $KeyDir = Get-VpeKeyDir }
    if (-not $StateDir) { $StateDir = Join-Path $Root '작업저장' }
    $local = Get-VpeLocalVersion $Root; $res.from = $local
    if (Test-Path -LiteralPath (Join-Path $KeyDir 'private.bin')) { $res.state = 'owner'; $res.why = '만든 사람 PC라 받지 않아요 (여기서 배포해요)'; return $res }
    $pubF = Join-Path $Root 'tools\update_pub.xml'
    if (-not (Test-Path -LiteralPath $pubF)) { $res.state = 'nokey'; $res.why = '공개 열쇠(update_pub.xml)가 없어요 — 만든 사람에게 새 공유용 묶음을 한 번 받아 주세요'; return $res }
    $pub = [IO.File]::ReadAllText($pubF, [Text.Encoding]::UTF8)
    # ① 가장 새 버전을 가진 곳 찾기 (서명이 맞는 것만)
    $best = $null; $why = New-Object System.Collections.ArrayList
    foreach ($src in $Sources) {
      try {
        $jb = Read-VpeSrc $src 'latest.json'; if (-not $jb) { continue }
        $sg = Read-VpeSrc $src 'latest.sig'; if (-not $sg) { [void]$why.Add("$src : 서명 파일 없음"); continue }
        if (-not (Test-VpeSig $jb $sg $pub)) { [void]$why.Add("$src : 서명이 맞지 않음 (받지 않음)"); continue }
        $m = [Text.Encoding]::UTF8.GetString($jb).TrimStart([char]0xFEFF) | ConvertFrom-Json
        if ($m.product -ne 'vpe-editor' -or $m.kind -eq 'release' -or [string]$m.version -notmatch '^\d{12}$') { [void]$why.Add("$src : 알 수 없는 묶음"); continue }
        if (-not $best -or [string]$m.version -gt [string]$best.m.version) { $best = @{ src = $src; m = $m; jb = $jb; sg = $sg } }
      } catch { [void]$why.Add("$src : $($_.Exception.Message)") }
    }
    if (-not $best) { $res.why = ($why -join ' / '); if ($why.Count) { $res.state = 'error' }; return $res }
    $m = $best.m; $res.to = [string]$m.version; $res.notes = [string]$m.notes
    if ([string]$m.version -le $local) { $res.state = 'none'; $res.why = '이미 최신이에요'; return $res }
    # ② 묶음(zip) 받기 · 지문 확인
    $zb = Read-VpeSrc $best.src 'latest.zip'
    if (-not $zb -or (Get-VpeSha $zb) -ne [string]$m.zip) { $res.state = 'error'; $res.why = '업데이트 묶음의 지문이 맞지 않아요 (아직 올라가는 중이거나 바뀐 파일) — 다음에 다시 확인해요'; return $res }
    $work = Join-Path $env:TEMP ('vpe_upd_' + [guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Force $work | Out-Null
    try {
      $zf = Join-Path $work 'p.zip'; [IO.File]::WriteAllBytes($zf, $zb)
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      $ex = Join-Path $work 'x'; [IO.Compression.ZipFile]::ExtractToDirectory($zf, $ex)
      $plan = New-Object System.Collections.ArrayList
      foreach ($f in @($m.files)) {
        $rel = [string]$f.path
        if ($VpeUpdFiles -notcontains $rel) { throw "허용되지 않은 파일: $rel" }
        $sp = Join-Path $ex $rel; if (-not (Test-Path -LiteralPath $sp -PathType Leaf)) { throw "묶음에 없는 파일: $rel" }
        $bytes = [IO.File]::ReadAllBytes($sp); if ((Get-VpeSha $bytes) -ne [string]$f.sha256) { throw "지문이 다른 파일: $rel" }
        [void]$plan.Add(@{ rel = $rel; bytes = $bytes })
      }
      if (-not ($plan | Where-Object { $_.rel -eq '영상사진편집기.html' })) { throw '편집기 파일이 없는 묶음' }
      # ③ 지금 버전 보관
      $bk = Join-Path $StateDir ('편집기_이전버전\' + $local + '_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
      foreach ($p in $plan) { $cur = Join-Path $Root $p.rel; if (Test-Path -LiteralPath $cur) { $d = Join-Path $bk $p.rel; New-Item -ItemType Directory -Force (Split-Path $d) | Out-Null; Copy-Item -LiteralPath $cur -Destination $d -Force } }
      $vfCur = Join-Path $Root 'tools\version.json'; if (Test-Path -LiteralPath $vfCur) { $d = Join-Path $bk 'tools\version.json'; New-Item -ItemType Directory -Force (Split-Path $d) | Out-Null; Copy-Item -LiteralPath $vfCur -Destination $d -Force }
      # ④ 배포 번호(받은 사람마다 다른 번호) 그대로 이어 받기
      $sid = ''
      $curHtml = Join-Path $Root '영상사진편집기.html'
      if (Test-Path -LiteralPath $curHtml) { $sid = Get-VpeShareIdOf ([IO.File]::ReadAllText($curHtml, [Text.Encoding]::UTF8)) }
      # ⑤ 바꾸기 (새 이름으로 쓴 뒤 바꿔치기 → 중간에 꺼져도 반쯤 바뀐 파일이 남지 않음)
      foreach ($p in $plan) {
        $dst = Join-Path $Root $p.rel; New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        $b = $p.bytes
        if ($sid -and $VpeShareIdFiles -contains $p.rel) { $t = Set-VpeShareId ([Text.Encoding]::UTF8.GetString($b)) $sid; $b = (New-Object Text.UTF8Encoding ($p.rel -like '*.txt')).GetPreamble() + [Text.Encoding]::UTF8.GetBytes($t.TrimStart([char]0xFEFF)) }
        [IO.File]::WriteAllBytes("$dst.updnew", $b); Move-Item -LiteralPath "$dst.updnew" -Destination $dst -Force
      }
      [IO.File]::WriteAllText((Join-Path $Root 'tools\version.json'), (@{ version = [string]$m.version; notes = [string]$m.notes; applied = (Get-Date).ToString('yyyy-MM-dd HH:mm') } | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
      # 🛡 서명된 목록을 원본 확인용으로 보관 (편집기가 켜질 때 고쳐진 곳이 없는지 확인)
      [IO.File]::WriteAllBytes((Join-Path $Root 'tools\release.json'), $best.jb); [IO.File]::WriteAllBytes((Join-Path $Root 'tools\release.sig'), $best.sg)
      $res.state = 'updated'; $res.backup = $bk
      New-Item -ItemType Directory -Force $StateDir | Out-Null
      [IO.File]::WriteAllText((Join-Path $StateDir '.업데이트상태.json'), (@{ from = $local; to = [string]$m.version; notes = [string]$m.notes; at = (Get-Date).ToString('yyyy-MM-dd HH:mm'); seen = $false } | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
    } finally { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
  } catch { $res.state = 'error'; $res.why = $_.Exception.Message }
  return $res
}

# 🛡 원본 확인: 이 편집기 파일들이 만든 사람이 서명한 그대로인지 (이름·저작권 표시·배포 번호를 고치거나 코드를 바꾸면 'tampered')
#    state: owner(만든 사람 PC) · unknown(확인 자료 없음) · ok(원본 그대로) · tampered(고쳐짐)
function Test-VpeRelease {
  param([string]$Root, [string]$KeyDir = '')
  $res = @{ state = 'unknown'; bad = @(); sid = ''; why = '' }
  try {
    if (-not $KeyDir) { $KeyDir = Get-VpeKeyDir }
    if (Test-Path -LiteralPath (Join-Path $KeyDir 'private.bin')) { $res.state = 'owner'; return $res }
    $pubF = Join-Path $Root 'tools\update_pub.xml'; $jf = Join-Path $Root 'tools\release.json'; $sf = Join-Path $Root 'tools\release.sig'
    if (-not ((Test-Path -LiteralPath $pubF) -and (Test-Path -LiteralPath $jf) -and (Test-Path -LiteralPath $sf))) { $res.why = '확인 자료 없음'; return $res }
    $jb = [IO.File]::ReadAllBytes($jf)
    if (-not (Test-VpeSig $jb ([IO.File]::ReadAllBytes($sf)) ([IO.File]::ReadAllText($pubF, [Text.Encoding]::UTF8)))) { $res.state = 'tampered'; $res.why = '원본 목록의 서명이 맞지 않아요'; return $res }
    $m = [Text.Encoding]::UTF8.GetString($jb).TrimStart([char]0xFEFF) | ConvertFrom-Json
    $hp = Join-Path $Root '영상사진편집기.html'
    if (-not (Test-Path -LiteralPath $hp)) { $res.state = 'tampered'; $res.why = '편집기 파일이 없어요'; return $res }
    $sid = Get-VpeShareIdOf ([IO.File]::ReadAllText($hp, [Text.Encoding]::UTF8)); $res.sid = $sid
    $bad = New-Object System.Collections.ArrayList
    foreach ($f in @($m.files)) {
      $rel = [string]$f.path; $p = Join-Path $Root $rel
      if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { if ($rel -eq '영상사진편집기.html') { [void]$bad.Add($rel) }; continue }
      $b = [IO.File]::ReadAllBytes($p); if ((Get-VpeSha $b) -eq [string]$f.sha256) { continue }
      $good = $false
      if ($VpeShareIdFiles -contains $rel) {
        # 배포 번호 자리를 원래 빈 자리로 되돌려 비교 (BOM 있는 것·없는 것 둘 다)
        $t = [Text.Encoding]::UTF8.GetString($b).TrimStart([char]0xFEFF)
        if ($sid) { $t = $t.Replace($sid, '__SHAREID__').Replace((Get-VpeHx $sid), '__SHAREHX__') }
        $nb = [Text.Encoding]::UTF8.GetBytes($t); $bom = (New-Object Text.UTF8Encoding $true).GetPreamble()
        $good = ((Get-VpeSha $nb) -eq [string]$f.sha256) -or ((Get-VpeSha ($bom + $nb)) -eq [string]$f.sha256)
      }
      if (-not $good) { [void]$bad.Add($rel) }
    }
    $res.bad = @($bad); $res.state = $(if ($bad.Count) { 'tampered' } else { 'ok' })
    if ($bad.Count) { $res.why = '원본과 다른 파일: ' + ($bad -join ', ') }
  } catch { $res.state = 'unknown'; $res.why = $_.Exception.Message }
  return $res
}
