' Opens the photo/video editor (works from any folder)
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
sh.Run "wscript.exe """ & d & "\tools\start.vbs""", 0, False
