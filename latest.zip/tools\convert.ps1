﻿# 드론·아이폰 영상(H.265/HEVC, HDR/HLG)을 편집기에서 열 수 있는 H.264 MP4로 바꿉니다.
# 모든 처리는 이 컴퓨터 안에서만 이루어집니다.
$ErrorActionPreference = 'Continue'
$Host.UI.RawUI.WindowTitle = '드론영상 변환하기'
$root = Split-Path $PSScriptRoot -Parent
$inDir = Join-Path $root '변환할_영상'
$outDir = Join-Path $root '변환된_영상'

function Find-Tool($name) {
  $cands = @(
    (Join-Path $root "ffmpeg\bin\$name.exe"),
    (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\$name.exe")
  )
  foreach ($c in $cands) { if (Test-Path $c) { return $c } }
  $g = Get-Command $name -ErrorAction SilentlyContinue
  if ($g) { return $g.Source }
  $p = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') -Filter "$name.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($p) { return $p.FullName }
  return $null
}

Write-Host ''
Write-Host '  ===== 드론·휴대폰 영상 변환하기 =====' -ForegroundColor Green
Write-Host '  H.265(HEVC) 영상을 편집기에서 열 수 있는 MP4(H.264)로 바꿔요.'
Write-Host ''

$ff = Find-Tool 'ffmpeg'; $fp = Find-Tool 'ffprobe'
if (-not $ff -or -not $fp) {
  Write-Host '  ⚠ 변환 도구(ffmpeg)가 아직 설치되지 않았어요.' -ForegroundColor Yellow
  Write-Host '    같은 폴더의 「변환도구_설치하기(처음 한 번만)」를 먼저 더블클릭하세요.'
  Write-Host ''
  Read-Host '  Enter 키를 누르면 닫혀요'
  exit 1
}

# 변환할 파일 모으기
$exts = '.mp4', '.mov', '.m4v', '.mkv', '.avi', '.mts', '.hevc'
$files = @()
foreach ($a in $args) {
  if (Test-Path $a -PathType Container) { $files += Get-ChildItem $a -File | Where-Object { $exts -contains $_.Extension.ToLower() } }
  elseif (Test-Path $a) { $files += Get-Item $a }
}
if (-not $files.Count) {
  New-Item -ItemType Directory -Force $inDir | Out-Null
  $files = @(Get-ChildItem $inDir -File | Where-Object { $exts -contains $_.Extension.ToLower() })
  if (-not $files.Count) {
    Write-Host '  변환할 영상이 없어요. 두 가지 방법 중 하나를 쓰세요:' -ForegroundColor Yellow
    Write-Host '   ① 영상 파일들을 이 「드론영상_변환하기」 아이콘 위에 끌어다 놓기'
    Write-Host "   ② 방금 열린 「변환할_영상」 폴더에 영상을 복사한 뒤, 다시 더블클릭"
    Start-Process explorer.exe $inDir
    Write-Host ''
    Read-Host '  Enter 키를 누르면 닫혀요'
    exit 0
  }
}

Write-Host "  영상 $($files.Count)개를 찾았어요."
Write-Host ''
Write-Host '  화질을 고르세요:'
Write-Host '    1 = 1080p (추천 · 편집이 부드럽고 빠름)'
Write-Host '    2 = 원본 크기 그대로 (4K · 파일 크고 편집이 느릴 수 있음)'
$q = if ($env:VPE_QUALITY) { $env:VPE_QUALITY } else { Read-Host '  번호 입력 후 Enter (그냥 Enter = 1)' }
$keep4k = ($q -eq '2')
New-Item -ItemType Directory -Force $outDir | Out-Null

$n = 0
foreach ($f in $files) {
  $n++
  Write-Host ''
  Write-Host "  [$n/$($files.Count)] $($f.Name)" -ForegroundColor Cyan
  $info = & $fp -v error -select_streams v:0 -show_entries stream=codec_name,color_transfer,height,width -of default=nw=1 "$($f.FullName)" 2>$null
  $codec = ($info | Where-Object { $_ -like 'codec_name=*' }) -replace 'codec_name=', ''
  $trc = ($info | Where-Object { $_ -like 'color_transfer=*' }) -replace 'color_transfer=', ''
  $h = [int](($info | Where-Object { $_ -like 'height=*' }) -replace 'height=', '')
  $w = [int](($info | Where-Object { $_ -like 'width=*' }) -replace 'width=', '')
  if (-not $codec) { Write-Host '    ⚠ 영상으로 읽을 수 없어서 건너뛰어요.' -ForegroundColor Yellow; continue }
  $hdr = ($trc -eq 'arib-std-b67' -or $trc -eq 'smpte2084')
  Write-Host ("    형식: {0}, {1}x{2}{3}" -f $codec, $w, $h, $(if ($hdr) { ', HDR(HLG) → 일반 색으로 바꿈' } else { '' }))

  $portrait = $h -gt $w
  $scale = if ($keep4k) { 'scale=trunc(iw/2)*2:trunc(ih/2)*2' } elseif ($portrait) { 'scale=1080:-2' } else { 'scale=-2:1080' }
  if (-not $keep4k -and [math]::Min($w, $h) -le 1080) { $scale = 'scale=trunc(iw/2)*2:trunc(ih/2)*2' }
  $vfHdr = "$scale,zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p"
  $vfSdr = "$scale,format=yuv420p"
  $out = Join-Path $outDir ($f.BaseName + '_편집용.mp4')
  $common = @('-hide_banner', '-loglevel', 'error', '-stats', '-y', '-i', $f.FullName)
  $enc = @('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', $out)
  $vf = if ($hdr) { $vfHdr } else { $vfSdr }
  & $ff @common -vf $vf @enc
  if ($LASTEXITCODE -ne 0 -and $hdr) {
    Write-Host '    색 변환 없이 다시 시도해요…' -ForegroundColor Yellow
    & $ff @common -vf $vfSdr @enc
  }
  if ($LASTEXITCODE -eq 0) { Write-Host "    ✅ 완료 → 변환된_영상\$([IO.Path]::GetFileName($out))" -ForegroundColor Green }
  else { Write-Host '    ❌ 변환 실패' -ForegroundColor Red }
}
Write-Host ''
Write-Host '  모두 끝났어요! 「변환된_영상」 폴더의 파일을 편집기에 넣으세요.' -ForegroundColor Green
if (-not $env:VPE_NOPAUSE) { Start-Process explorer.exe $outDir; Read-Host '  Enter 키를 누르면 닫혀요' }
